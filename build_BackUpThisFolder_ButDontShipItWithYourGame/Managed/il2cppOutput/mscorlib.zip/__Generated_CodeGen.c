﻿#include "pch-c.h"


#include "codegen/il2cpp-codegen-metadata.h"





extern void __Il2CppComObject_Finalize_m720B2062F661A0770A32D24B731AD4AFE314A5CD (void);
extern void __Il2CppComDelegate_Finalize_mC9F8EA94444C3AF0A43CC723A23EE4D8B7984F8C (void);
static Il2CppMethodPointer s_methodPointers[3] = 
{
	NULL,
	__Il2CppComObject_Finalize_m720B2062F661A0770A32D24B731AD4AFE314A5CD,
	__Il2CppComDelegate_Finalize_mC9F8EA94444C3AF0A43CC723A23EE4D8B7984F8C,
};
static const int32_t s_InvokerIndices[3] = 
{
	-1,
	14414,
	14414,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g___Generated_CodeGenModule;
const Il2CppCodeGenModule g___Generated_CodeGenModule = 
{
	"__Generated",
	3,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
