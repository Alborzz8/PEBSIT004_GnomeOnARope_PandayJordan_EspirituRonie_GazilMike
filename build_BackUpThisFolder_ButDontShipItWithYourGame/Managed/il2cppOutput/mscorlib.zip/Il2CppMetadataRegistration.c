﻿#include "pch-c.h"


#include "codegen/il2cpp-codegen-metadata.h"





extern Il2CppGenericClass* const g_Il2CppGenericTypes[];
extern const Il2CppGenericInst* const g_Il2CppGenericInstTable[];
extern const Il2CppGenericMethodFunctionsDefinitions g_Il2CppGenericMethodFunctions[];
extern const Il2CppType* const  g_Il2CppTypeTable[];
extern const Il2CppMethodSpec g_Il2CppMethodSpecTable[];
extern const int32_t* g_FieldOffsetTable[];
extern const Il2CppTypeDefinitionSizes* g_Il2CppTypeDefinitionSizesTable[];
IL2CPP_EXTERN_C const Il2CppMetadataRegistration g_MetadataRegistration;
const Il2CppMetadataRegistration g_MetadataRegistration = 
{
	11038,
	g_Il2CppGenericTypes,
	8045,
	g_Il2CppGenericInstTable,
	111177,
	g_Il2CppGenericMethodFunctions,
	32820,
	g_Il2CppTypeTable,
	126518,
	g_Il2CppMethodSpecTable,
	8651,
	g_FieldOffsetTable,
	8651,
	g_Il2CppTypeDefinitionSizesTable,
	0,
	NULL,
};
