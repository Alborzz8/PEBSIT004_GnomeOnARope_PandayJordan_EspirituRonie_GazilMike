﻿#include "pch-cpp.hpp"






struct Func_2_t971797D45092E7DB796042DDE8CB0C9E07DE40D1;
struct Func_2_t0D05225CFA7E020459CF8B28462C673A5811BE16;
struct List_1_t46F5B78A1A3903DB7296772C4667E1301E64085D;
struct List_1_t9EDAF087DC60E19A2BB0DE20322CAFC776709861;
struct List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B;
struct AngleRangeInfoU5BU5D_t8AE5F89B8CA102A1093EFEA4E67B9364AC690BC8;
struct CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB;
struct DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771;
struct SpriteU5BU5D_tCEE379E10CAD9DBFA770B331480592548ED0EA1B;
struct Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07;
struct AsyncCallback_t7FEF460CBDCFB9C5FA2EF776984778B9A4145F4C;
struct BurstCompilerOptions_t5F93118F305E1B0C950C6F9AF8BCA74033DA01C9;
struct Byte_t94D9231AC217BE4D2E004C4CD32DF6D099EA41A3;
struct CancellationTokenSource_tAAE1E0033BCFC233801F8CB4CED5C852B350CB7B;
struct Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3;
struct Delegate_t;
struct DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E;
struct EdgeCollider2D_tB7A39F2B1345894C40577A62FD62244702DE3710;
struct GameObject_t76FEDD663AB33C991A9C9A23129337651094216F;
struct IAsyncResult_t7B9B5A0ECB35DCEC31B8A8122C37D687369253B5;
struct MethodInfo_t;
struct MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71;
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C;
struct PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E;
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A;
struct Spline_tD674213224F697425072FBF76AE3FD203AD2B818;
struct SpriteShape_tD8E4AB9593376F28E8325314A03A49A19395858C;
struct SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17;
struct SpriteShapeGeometryCache_tC9E1C36A4286F9AAF63CCC72F38C4135EEBE8E9E;
struct SpriteShapeGeometryCreator_t7A84B10A6429A625610D783C12A86ED5F1C515C4;
struct SpriteShapeGeometryModifier_tBCAFA8CB38E611DA5EB0D1F2E6DD67762302369F;
struct SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB;
struct SpriteShapeRenderer_tE998BB73CF661079736CCC23617E597AB230A4AC;
struct String_t;
struct Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4;
struct Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1;
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;
struct CommandBuilder_tA2E5D7A513FE45173EA395D67B25DB94E42CCA84;
struct U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74;
struct UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA;

IL2CPP_EXTERN_C RuntimeClass* Allocator_t996642592271AAD9EE688F142741D512C07B5824_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* BezierUtility_t450F38689B5013A23432043C5922D64496EF5E60_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ModuleHandle_t2F8BE4233858E78501EF0B4D650CECD9A6D5D9F4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteralB97EA8E93DF3A597AEFDD8BACBE2AD61BB9CAE61;
IL2CPP_EXTERN_C const RuntimeMethod* BurstCompiler_CompileFunctionPointer_TisUTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA_m185061C1CB9EC862782431884C54DCBB4BA2A702_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* FunctionPointer_1_get_Value_mCBDE3C3B018EFC1FB10C35410FBD998F12C042F2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* SpriteShapeGenerator_UTessellator_mA975B9F66E80F2334124BFADD19F331AB2F6E90D_RuntimeMethod_var;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;

struct DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
struct U24BurstDirectCallInitializer_t212535ABB094519322C732872D4556599150D041  : public RuntimeObject
{
};
struct U3CPrivateImplementationDetailsU3E_t055A32C92038C77A870518DD3BF5A6A1A4FC96DE  : public RuntimeObject
{
};
struct BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8  : public RuntimeObject
{
};
struct BurstCompilerOptions_t5F93118F305E1B0C950C6F9AF8BCA74033DA01C9  : public RuntimeObject
{
	bool ____enableBurstCompilation;
	bool ____enableBurstCompileSynchronously;
	bool ____enableBurstSafetyChecks;
	bool ____enableBurstTimings;
	bool ____enableBurstDebug;
	bool ____forceEnableBurstSafetyChecks;
	bool ___U3CIsGlobalU3Ek__BackingField;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___U3COptionsChangedU3Ek__BackingField;
};
struct Spline_tD674213224F697425072FBF76AE3FD203AD2B818  : public RuntimeObject
{
	bool ___m_IsOpenEnded;
	List_1_t46F5B78A1A3903DB7296772C4667E1301E64085D* ___m_ControlPoints;
	int32_t ___m_DirtyIndex;
};
struct String_t  : public RuntimeObject
{
	int32_t ____stringLength;
	Il2CppChar ____firstChar;
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};
struct U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74  : public RuntimeObject
{
};
struct UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280  : public RuntimeObject
{
};
struct NativeSlice_1_tBDD0B6C963222DE23BD34911416213E058F9FBAF 
{
	uint8_t* ___m_Buffer;
	int32_t ___m_Stride;
	int32_t ___m_Length;
};
struct NativeSlice_1_t4B5C42A704ED060AB92A8716135FE435B1E6C23A 
{
	uint8_t* ___m_Buffer;
	int32_t ___m_Stride;
	int32_t ___m_Length;
};
struct NativeSlice_1_tA687F314957178F2A299D03D59B960DDC218680F 
{
	uint8_t* ___m_Buffer;
	int32_t ___m_Stride;
	int32_t ___m_Length;
};
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	bool ___m_value;
};
struct Byte_t94D9231AC217BE4D2E004C4CD32DF6D099EA41A3 
{
	uint8_t ___m_value;
};
struct Double_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F 
{
	double ___m_value;
};
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2  : public ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F
{
};
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_pinvoke
{
};
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_com
{
};
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	int32_t ___m_value;
};
struct Int64_t092CFB123BE63C28ACDAF65C68F21A526050DBA3 
{
	int64_t ___m_value;
};
struct IntPtr_t 
{
	void* ___m_value;
};
struct JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 
{
	uint64_t ___jobGroup;
	int32_t ___version;
};
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 
{
	float ___m00;
	float ___m10;
	float ___m20;
	float ___m30;
	float ___m01;
	float ___m11;
	float ___m21;
	float ___m31;
	float ___m02;
	float ___m12;
	float ___m22;
	float ___m32;
	float ___m03;
	float ___m13;
	float ___m23;
	float ___m33;
};
struct Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 
{
	float ___x;
	float ___y;
	float ___z;
	float ___w;
};
struct Single_t4530F2FF86FCB0DC29F35385CA1BD21BE294761C 
{
	float ___m_value;
};
struct SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5 
{
	int32_t ___m_GeomIndex;
	int32_t ___m_IndexCount;
	int32_t ___m_VertexCount;
	int32_t ___m_SpriteIndex;
};
struct UInt16_tF4C148C876015C212FD72652D0B6ED8CC247A455 
{
	uint16_t ___m_value;
};
struct Vec3_t2DC07E9249C572CF68A4D54873B4038A68B77E74 
{
	float ___X;
	float ___Y;
	float ___Z;
};
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 
{
	float ___x;
	float ___y;
};
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 
{
	float ___x;
	float ___y;
	float ___z;
};
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};
struct float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA 
{
	float ___x;
	float ___y;
};
struct float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E 
{
	float ___x;
	float ___y;
	float ___z;
};
struct float4_t89D9A294E7A79BD81BFBDD18654508532958555E 
{
	float ___x;
	float ___y;
	float ___z;
	float ___w;
};
struct int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A 
{
	int32_t ___x;
	int32_t ___y;
};
struct int4_tBA77D4945786DE82C3A487B33955EA1004996052 
{
	int32_t ___x;
	int32_t ___y;
	int32_t ___z;
	int32_t ___w;
};
#pragma pack(push, tp, 1)
struct __StaticArrayInitTypeSizeU3D1952_tFECFDE0E8FDEC11DBFE773D1BCEB9E8C41FC981E 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D1952_tFECFDE0E8FDEC11DBFE773D1BCEB9E8C41FC981E__padding[1952];
	};
};
#pragma pack(pop, tp)
#pragma pack(push, tp, 1)
struct __StaticArrayInitTypeSizeU3D2163_t96EBC4A405B3B0C0F1D467BDBAA8E8A10BEDDD6D 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D2163_t96EBC4A405B3B0C0F1D467BDBAA8E8A10BEDDD6D__padding[2163];
	};
};
#pragma pack(pop, tp)
struct FunctionPointer_1_tE1DC1EC606FB2242FB50357BBA39BB4AEDECFCB2 
{
	intptr_t ____ptr;
};
struct FunctionPointer_1_tE9B0E7B7584968B2ED8D94E976B6AB8C67D4E4D4 
{
	intptr_t ____ptr;
};
struct Allocator_t996642592271AAD9EE688F142741D512C07B5824 
{
	int32_t ___value__;
};
struct ContourVertex_tCF411C2A25CB1E379D7566058ACD30AE23E7FC66 
{
	Vec3_t2DC07E9249C572CF68A4D54873B4038A68B77E74 ___Position;
	RuntimeObject* ___Data;
};
struct ContourVertex_tCF411C2A25CB1E379D7566058ACD30AE23E7FC66_marshaled_pinvoke
{
	Vec3_t2DC07E9249C572CF68A4D54873B4038A68B77E74 ___Position;
	Il2CppIUnknown* ___Data;
};
struct ContourVertex_tCF411C2A25CB1E379D7566058ACD30AE23E7FC66_marshaled_com
{
	Vec3_t2DC07E9249C572CF68A4D54873B4038A68B77E74 ___Position;
	Il2CppIUnknown* ___Data;
};
struct Delegate_t  : public RuntimeObject
{
	intptr_t ___method_ptr;
	intptr_t ___invoke_impl;
	RuntimeObject* ___m_target;
	intptr_t ___method;
	intptr_t ___delegate_trampoline;
	intptr_t ___extra_arg;
	intptr_t ___method_code;
	intptr_t ___interp_method;
	intptr_t ___interp_invoke_impl;
	MethodInfo_t* ___method_info;
	MethodInfo_t* ___original_method_info;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data;
	bool ___method_is_virtual;
};
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr;
	intptr_t ___invoke_impl;
	Il2CppIUnknown* ___m_target;
	intptr_t ___method;
	intptr_t ___delegate_trampoline;
	intptr_t ___extra_arg;
	intptr_t ___method_code;
	intptr_t ___interp_method;
	intptr_t ___interp_invoke_impl;
	MethodInfo_t* ___method_info;
	MethodInfo_t* ___original_method_info;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data;
	int32_t ___method_is_virtual;
};
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr;
	intptr_t ___invoke_impl;
	Il2CppIUnknown* ___m_target;
	intptr_t ___method;
	intptr_t ___delegate_trampoline;
	intptr_t ___extra_arg;
	intptr_t ___method_code;
	intptr_t ___interp_method;
	intptr_t ___interp_invoke_impl;
	MethodInfo_t* ___method_info;
	MethodInfo_t* ___original_method_info;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data;
	int32_t ___method_is_virtual;
};
struct NativeArrayOptions_t3E979EEF4B4840228A7692A97DA07553C6465F1D 
{
	int32_t ___value__;
};
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C  : public RuntimeObject
{
	intptr_t ___m_CachedPtr;
};
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr;
};
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
	intptr_t ___m_CachedPtr;
};
struct ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD 
{
	intptr_t ___m_Ptr;
};
struct ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___position;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___leftTangent;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___rightTangent;
	int32_t ___mode;
};
struct SpriteShapeObjectPlacementMode_t9E70BA2334ED43D7A80BEA8C89F0CF84D86D1EF9 
{
	int32_t ___value__;
};
struct SpriteShapeParameters_tC047BDC50B45EE3C0035646195EFA31FB89F2E45 
{
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___transform;
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___fillTexture;
	uint32_t ___fillScale;
	uint32_t ___splineDetail;
	float ___angleThreshold;
	float ___borderPivot;
	float ___bevelCutoff;
	float ___bevelSize;
	bool ___carpet;
	bool ___smartSprite;
	bool ___adaptiveUV;
	bool ___spriteBorders;
	bool ___stretchUV;
};
struct SpriteShapeParameters_tC047BDC50B45EE3C0035646195EFA31FB89F2E45_marshaled_pinvoke
{
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___transform;
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___fillTexture;
	uint32_t ___fillScale;
	uint32_t ___splineDetail;
	float ___angleThreshold;
	float ___borderPivot;
	float ___bevelCutoff;
	float ___bevelSize;
	int32_t ___carpet;
	int32_t ___smartSprite;
	int32_t ___adaptiveUV;
	int32_t ___spriteBorders;
	int32_t ___stretchUV;
};
struct SpriteShapeParameters_tC047BDC50B45EE3C0035646195EFA31FB89F2E45_marshaled_com
{
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___transform;
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___fillTexture;
	uint32_t ___fillScale;
	uint32_t ___splineDetail;
	float ___angleThreshold;
	float ___borderPivot;
	float ___bevelCutoff;
	float ___bevelSize;
	int32_t ___carpet;
	int32_t ___smartSprite;
	int32_t ___adaptiveUV;
	int32_t ___spriteBorders;
	int32_t ___stretchUV;
};
struct float4x4_t7EDD16F7F57DC7F61A6302535F7C19FB97915DF2 
{
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___c0;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___c1;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___c2;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___c3;
};
struct JobAngleRange_t974C3D0183C9572CE9C7D88703CABC5FAE543F13 
{
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___spriteAngles;
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___spriteData;
};
struct JobContourPoint_t4C410C8E8FEECD48C1DE496790BA15C88F09E3E3 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___position;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___ptData;
};
struct JobControlPoint_t4A1C76318BCFAEC1F3FBA7879A2FB6FD0AFB2A36 
{
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___cpData;
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___exData;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___cpInfo;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___position;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___tangentLt;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___tangentRt;
};
struct JobCornerInfo_t4B00296B36DDE3A9780DD95B9FF3D93CD8F3FD99 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___bottom;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___top;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___left;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___right;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___cornerData;
};
struct JobIntersectPoint_t0F9A7C2D6E77A6B8C54351175052D3E5691BDB0C 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___top;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___bottom;
};
struct JobParameters_tB5052920FED049655BC1AC4E0520234C4DFBFFAA 
{
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___shapeData;
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___splineData;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___curveData;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___fillData;
};
struct JobSegmentInfo_tA77A98E2F21524FDF0D28D2E53452DF45FC40481 
{
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___sgInfo;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___spriteInfo;
};
struct JobShapeVertex_t630D64AD32E441EC9BC0B7B54948F861B2ECE9CC 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___pos;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___uv;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___tan;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___meta;
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___sprite;
};
struct JobSpriteInfo_t002F5BF7D329A7F7A8DA7E9CB9B923C73B1C5E29 
{
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___texRect;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___texData;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___uvInfo;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___metaInfo;
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___border;
};
struct NativeArray_1_t596D8D9BF28AE72A671779EB28469319AC3F1147 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t77D78B577AF7E0DD9EB5B192AF05EF90AE6F567D 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t2BC742D9A03AF608A0AB5B638F49639E1C7BD6ED 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t275C00CC374DEA66C69B3BB3992116F315A8E934 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t1319594EE236701FE431CF2885AEB88373076DA8 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t6A9440FA4CD97A8AF79CFC6B5EACC6334B735C72 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t1B14A657C1CECB432BE147E154F55E2CA5137892 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tD02731CFBE491B5BFFD8328166FDE46F8D844B1A 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tE2E3F30FD2D061E2FA4FCA86BD8F1118E53219C9 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tDE55A9B6B2881EDDA38508CBC140670DE3C5F42A 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t4208ED8A2AD50A8F390E613A7D4B98392469DE9A 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t6F6DC3ADF226AD65ED9319CB852676AE3EEEDB13 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};
struct GameObject_t76FEDD663AB33C991A9C9A23129337651094216F  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};
struct MulticastDelegate_t  : public Delegate_t
{
	DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771* ___delegates;
};
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates;
};
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates;
};
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A_marshaled_pinvoke : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
};
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A_marshaled_com : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
};
struct AsyncCallback_t7FEF460CBDCFB9C5FA2EF776984778B9A4145F4C  : public MulticastDelegate_t
{
};
struct Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA  : public Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3
{
};
struct SpriteShapeGenerator_tE3C79C2D9685232AD17AB7FA803F44FA92DB854E 
{
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___generateGeometry;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___generateCollider;
	JobParameters_tB5052920FED049655BC1AC4E0520234C4DFBFFAA ___m_ShapeParams;
	NativeArray_1_t6F6DC3ADF226AD65ED9319CB852676AE3EEEDB13 ___m_SpriteInfos;
	NativeArray_1_t6F6DC3ADF226AD65ED9319CB852676AE3EEEDB13 ___m_CornerSpriteInfos;
	NativeArray_1_t6A9440FA4CD97A8AF79CFC6B5EACC6334B735C72 ___m_AngleRanges;
	NativeArray_1_t4208ED8A2AD50A8F390E613A7D4B98392469DE9A ___m_Segments;
	int32_t ___m_SegmentCount;
	NativeArray_1_t1B14A657C1CECB432BE147E154F55E2CA5137892 ___m_ContourPoints;
	int32_t ___m_ContourPointCount;
	NativeArray_1_tE2E3F30FD2D061E2FA4FCA86BD8F1118E53219C9 ___m_Corners;
	int32_t ___m_CornerCount;
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___m_TessPoints;
	int32_t ___m_TessPointCount;
	NativeArray_1_tD02731CFBE491B5BFFD8328166FDE46F8D844B1A ___m_ControlPoints;
	int32_t ___m_ControlPointCount;
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___m_CornerCoordinates;
	NativeArray_1_tD02731CFBE491B5BFFD8328166FDE46F8D844B1A ___m_GeneratedControlPoints;
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___m_SpriteIndices;
	NativeArray_1_tDE55A9B6B2881EDDA38508CBC140670DE3C5F42A ___m_Intersectors;
	int32_t ___m_IndexArrayCount;
	NativeArray_1_t275C00CC374DEA66C69B3BB3992116F315A8E934 ___m_IndexArray;
	int32_t ___m_VertexArrayCount;
	NativeSlice_1_t4B5C42A704ED060AB92A8716135FE435B1E6C23A ___m_PosArray;
	NativeSlice_1_tBDD0B6C963222DE23BD34911416213E058F9FBAF ___m_Uv0Array;
	NativeSlice_1_tA687F314957178F2A299D03D59B960DDC218680F ___m_TanArray;
	int32_t ___m_GeomArrayCount;
	NativeArray_1_t2BC742D9A03AF608A0AB5B638F49639E1C7BD6ED ___m_GeomArray;
	int32_t ___m_ColliderPointCount;
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___m_ColliderPoints;
	int32_t ___m_ShadowPointCount;
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___m_ShadowPoints;
	NativeArray_1_t596D8D9BF28AE72A671779EB28469319AC3F1147 ___m_Bounds;
	NativeArray_1_t77D78B577AF7E0DD9EB5B192AF05EF90AE6F567D ___m_Stats;
	int32_t ___m_IndexDataCount;
	int32_t ___m_VertexDataCount;
	int32_t ___m_ColliderDataCount;
	int32_t ___m_ShadowDataCount;
	int32_t ___m_ActiveIndexCount;
	int32_t ___m_ActiveVertexCount;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___m_FirstLT;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___m_FirstLB;
	float4x4_t7EDD16F7F57DC7F61A6302535F7C19FB97915DF2 ___m_Transform;
	int32_t ___kModeLinear;
	int32_t ___kModeContinous;
	int32_t ___kModeBroken;
	int32_t ___kModeUTess;
	int32_t ___kCornerTypeOuterTopLeft;
	int32_t ___kCornerTypeOuterTopRight;
	int32_t ___kCornerTypeOuterBottomLeft;
	int32_t ___kCornerTypeOuterBottomRight;
	int32_t ___kCornerTypeInnerTopLeft;
	int32_t ___kCornerTypeInnerTopRight;
	int32_t ___kCornerTypeInnerBottomLeft;
	int32_t ___kCornerTypeInnerBottomRight;
	int32_t ___kControlPointCount;
	int32_t ___kMaxArrayCount;
	float ___kEpsilon;
	float ___kEpsilonOrder;
	float ___kEpsilonRelaxed;
	float ___kExtendSegment;
	float ___kRenderQuality;
	float ___kOptimizeRender;
	float ___kColliderQuality;
	float ___kOptimizeCollider;
	float ___kShadowQuality;
	float ___kLowestQualityTolerance;
	float ___kHighestQualityTolerance;
};
struct SpriteShapeGeometryCreator_t7A84B10A6429A625610D783C12A86ED5F1C515C4  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
};
struct SpriteShapeGeometryModifier_tBCAFA8CB38E611DA5EB0D1F2E6DD67762302369F  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
};
struct Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1  : public Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3
{
};
struct UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA  : public MulticastDelegate_t
{
};
struct MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71  : public Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA
{
	CancellationTokenSource_tAAE1E0033BCFC233801F8CB4CED5C852B350CB7B* ___m_CancellationTokenSource;
};
struct SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	SpriteShape_tD8E4AB9593376F28E8325314A03A49A19395858C* ___m_ActiveSpriteShape;
	EdgeCollider2D_tB7A39F2B1345894C40577A62FD62244702DE3710* ___m_EdgeCollider2D;
	PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* ___m_PolygonCollider2D;
	SpriteShapeRenderer_tE998BB73CF661079736CCC23617E597AB230A4AC* ___m_SpriteShapeRenderer;
	SpriteShapeGeometryCache_tC9E1C36A4286F9AAF63CCC72F38C4135EEBE8E9E* ___m_SpriteShapeGeometryCache;
	SpriteU5BU5D_tCEE379E10CAD9DBFA770B331480592548ED0EA1B* ___m_SpriteArray;
	SpriteU5BU5D_tCEE379E10CAD9DBFA770B331480592548ED0EA1B* ___m_EdgeSpriteArray;
	SpriteU5BU5D_tCEE379E10CAD9DBFA770B331480592548ED0EA1B* ___m_CornerSpriteArray;
	AngleRangeInfoU5BU5D_t8AE5F89B8CA102A1093EFEA4E67B9364AC690BC8* ___m_AngleRangeInfoArray;
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___m_ColliderData;
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___m_ShadowData;
	NativeArray_1_t1319594EE236701FE431CF2885AEB88373076DA8 ___m_TangentData;
	NativeArray_1_t77D78B577AF7E0DD9EB5B192AF05EF90AE6F567D ___m_Statistics;
	bool ___m_DynamicOcclusionLocal;
	bool ___m_DynamicOcclusionOverriden;
	bool ___m_TessellationNeedsFallback;
	bool ___m_WaitForBake;
	int32_t ___m_ActiveSplineHash;
	int32_t ___m_ActiveSpriteShapeHash;
	int32_t ___m_MaxArrayCount;
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 ___m_JobHandle;
	SpriteShapeParameters_tC047BDC50B45EE3C0035646195EFA31FB89F2E45 ___m_ActiveShapeParameters;
	Spline_tD674213224F697425072FBF76AE3FD203AD2B818* ___m_Spline;
	SpriteShape_tD8E4AB9593376F28E8325314A03A49A19395858C* ___m_SpriteShape;
	float ___m_FillPixelPerUnit;
	float ___m_StretchTiling;
	int32_t ___m_SplineDetail;
	bool ___m_AdaptiveUV;
	bool ___m_StretchUV;
	bool ___m_WorldSpaceUV;
	float ___m_CornerAngleThreshold;
	int32_t ___m_ColliderDetail;
	float ___m_ColliderOffset;
	bool ___m_UpdateCollider;
	bool ___m_EnableTangents;
	bool ___m_GeometryCached;
	bool ___m_UTess2D;
	bool ___m_UpdateShadow;
	int32_t ___m_ShadowDetail;
	float ___m_ShadowOffset;
	float ___m_BoundsScale;
	bool ___m_UpdateGeometry;
	SpriteShapeGeometryCreator_t7A84B10A6429A625610D783C12A86ED5F1C515C4* ___m_Creator;
	List_1_t9EDAF087DC60E19A2BB0DE20322CAFC776709861* ___m_Modifiers;
	List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* ___m_ColliderSegment;
	List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* ___m_ShadowSegment;
};
struct SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* ___m_SpriteShapeController;
	bool ___m_SetNormal;
	int32_t ___m_Mode;
	int32_t ___m_StartPoint;
	int32_t ___m_EndPoint;
	float ___m_Ratio;
	int32_t ___m_ActiveHashCode;
};
struct U3CPrivateImplementationDetailsU3E_t055A32C92038C77A870518DD3BF5A6A1A4FC96DE_StaticFields
{
	__StaticArrayInitTypeSizeU3D2163_t96EBC4A405B3B0C0F1D467BDBAA8E8A10BEDDD6D ___CF7B1B9098872AEA55D4C2A3373825BBCE06698EA178180B47103C50B5A6DF62;
	__StaticArrayInitTypeSizeU3D1952_tFECFDE0E8FDEC11DBFE773D1BCEB9E8C41FC981E ___E20E9D6DC96DBC0335D5FAEB62C204397AF9C55917BD4284411EC12F2BCBE9D1;
};
struct BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_StaticFields
{
	bool ____IsEnabled;
	BurstCompilerOptions_t5F93118F305E1B0C950C6F9AF8BCA74033DA01C9* ___Options;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___OnCompileILPPMethod2;
	MethodInfo_t* ___DummyMethodInfo;
};
struct BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_ThreadStaticFields
{
	CommandBuilder_tA2E5D7A513FE45173EA395D67B25DB94E42CCA84* ____cmdBuilder;
};
struct BurstCompilerOptions_t5F93118F305E1B0C950C6F9AF8BCA74033DA01C9_StaticFields
{
	bool ___ForceDisableBurstCompilation;
	bool ___ForceBurstCompilationSynchronously;
	bool ___IsSecondaryUnityProcess;
};
struct Spline_tD674213224F697425072FBF76AE3FD203AD2B818_StaticFields
{
	String_t* ___KErrorMessage;
	float ___KEpsilon;
};
struct String_t_StaticFields
{
	String_t* ___Empty;
};
struct U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74_StaticFields
{
	U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74* ___U3CU3E9;
	Func_2_t0D05225CFA7E020459CF8B28462C673A5811BE16* ___U3CU3E9__155_0;
	Func_2_t971797D45092E7DB796042DDE8CB0C9E07DE40D1* ___U3CU3E9__155_1;
};
struct UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_StaticFields
{
	intptr_t ___Pointer;
};
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	String_t* ___TrueString;
	String_t* ___FalseString;
};
struct IntPtr_t_StaticFields
{
	intptr_t ___Zero;
};
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6_StaticFields
{
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___zeroMatrix;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___identityMatrix;
};
struct Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974_StaticFields
{
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___identityQuaternion;
};
struct Vec3_t2DC07E9249C572CF68A4D54873B4038A68B77E74_StaticFields
{
	Vec3_t2DC07E9249C572CF68A4D54873B4038A68B77E74 ___Zero;
};
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_StaticFields
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___zeroVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___oneVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___upVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___downVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___leftVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___rightVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___positiveInfinityVector;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___negativeInfinityVector;
};
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___zeroVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___oneVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___upVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___downVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___leftVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___rightVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___forwardVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___backVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___positiveInfinityVector;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___negativeInfinityVector;
};
struct float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_StaticFields
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___zero;
};
struct float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E_StaticFields
{
	float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___zero;
};
struct float4_t89D9A294E7A79BD81BFBDD18654508532958555E_StaticFields
{
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___zero;
};
struct int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_StaticFields
{
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___zero;
};
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_StaticFields
{
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject;
};
struct SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17_StaticFields
{
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___generateGeometry;
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___generateCollider;
};
struct SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_StaticFields
{
	float ___kMaxDistance;
	int32_t ___kMaxIteration;
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
struct DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771  : public RuntimeArray
{
	ALIGN_FIELD (8) Delegate_t* m_Items[1];

	inline Delegate_t* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Delegate_t** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Delegate_t* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Delegate_t* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Delegate_t** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Delegate_t* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};


IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR FunctionPointer_1_tE1DC1EC606FB2242FB50357BBA39BB4AEDECFCB2 BurstCompiler_CompileFunctionPointer_TisRuntimeObject_m9AB9AE50036FBC10C6765A0FAC83200CAEC21384_gshared (RuntimeObject* ___0_delegateMethod, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR intptr_t FunctionPointer_1_get_Value_m71D7FF781C694A7C4EE28362DFC78D8DDFE9A105_gshared_inline (FunctionPointer_1_tE1DC1EC606FB2242FB50357BBA39BB4AEDECFCB2* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_gshared (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_gshared (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_gshared (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_gshared (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_gshared (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_gshared (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, const RuntimeMethod* method) ;

IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mA91FE5EA2C14E43491278E311B2F74B7478EF999 (U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2 (RuntimeObject* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UTessellator_0000017FU24PostfixBurstDelegate__ctor_m7D82A379E92F612522917026D1FBB234A0299719 (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, RuntimeObject* ___0_p, intptr_t ___1_p, const RuntimeMethod* method) ;
inline FunctionPointer_1_tE9B0E7B7584968B2ED8D94E976B6AB8C67D4E4D4 BurstCompiler_CompileFunctionPointer_TisUTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA_m185061C1CB9EC862782431884C54DCBB4BA2A702 (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* ___0_delegateMethod, const RuntimeMethod* method)
{
	return ((  FunctionPointer_1_tE9B0E7B7584968B2ED8D94E976B6AB8C67D4E4D4 (*) (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA*, const RuntimeMethod*))BurstCompiler_CompileFunctionPointer_TisRuntimeObject_m9AB9AE50036FBC10C6765A0FAC83200CAEC21384_gshared)(___0_delegateMethod, method);
}
inline intptr_t FunctionPointer_1_get_Value_mCBDE3C3B018EFC1FB10C35410FBD998F12C042F2_inline (FunctionPointer_1_tE9B0E7B7584968B2ED8D94E976B6AB8C67D4E4D4* __this, const RuntimeMethod* method)
{
	return ((  intptr_t (*) (FunctionPointer_1_tE9B0E7B7584968B2ED8D94E976B6AB8C67D4E4D4*, const RuntimeMethod*))FunctionPointer_1_get_Value_m71D7FF781C694A7C4EE28362DFC78D8DDFE9A105_gshared_inline)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UTessellator_0000017FU24BurstDirectCall_GetFunctionPointerDiscard_m674170764EDF0A0753BD85F5B4326892F27ABA44 (intptr_t* ___0_p, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool BurstCompiler_get_IsEnabled_m55FDBCB2279A83AC8926260034F870E3A11116C7 (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR intptr_t UTessellator_0000017FU24BurstDirectCall_GetFunctionPointer_m5DDBAB15141B65F9C34F7A02735B490B7CB79DFB (const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_NO_INLINE IL2CPP_METHOD_ATTR void SpriteShapeGenerator_UTessellatorU24BurstManaged_m6F4F57B7363784CE1724AE26829C356319E88118_inline (SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ScriptableObject__ctor_mD037FDB0B487295EA47F79A4DB1BF1846C9087FF (ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___0_x, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeController_get_splineHashCode_m5FD24A66B300EA0F8E1A1B0E5100ED3D0AA8FB98_inline (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeController_get_spriteShapeHashCode_mF2D6ABCAF590DFC5A0461E61A8B78356FD2FB520_inline (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56 (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1 (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Transform_get_rotation_m32AF40CA0D50C797DA639A696F8EAEC7524C179C (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool SpriteShapeObjectPlacement_get_setNormal_mDF4F4E07D5CD4B8A7D5A3B1A280BB21FBD8A0567_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_get_startPoint_m1C539FDCDDB00A0918771704D55D113549A08D12_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_get_endPoint_m1183FA74B1AF9A9806EC708DC9AB9FC183983335_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Vector3_GetHashCode_mB08429DC931A85BD29CE11B9ABC77DE7E0E46327_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Quaternion_GetHashCode_m5F55C34C98E437376595E722BE4EB8A70434F049_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline (double* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float SpriteShapeObjectPlacement_get_ratio_m1AD37D2E67595975F88822C70707DF5EFB8B5F3B_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool SpriteShapeObjectPlacement_Place_m67C08775427481BF5175EF5BA5455F6B837140E9 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Vector3_Dot_mBB86BB940AA0A32FA7D3C02AC42E5BC7095A5D52_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_lhs, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeController_get_splineDetail_mB03C316DE81143E38A30C15C339D36DAD7C56E33_inline (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 BezierUtility_BezierPoint_m58FBF49282434261BFE28A39F3C891889F6FAF54 (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_startRightTangent, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_startPosition, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___2_endPosition, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___3_endLeftTangent, float ___4_t, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_op_Implicit_mE1831A3AC179B7EB3236F8202EC8DD5CE05376AB (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_v, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_distance_m516495927BCF37E20FFA3E99C821062D329DFFF8_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_x, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371 (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 Transform_get_localToWorldMatrix_m5D35188766856338DD21DE756F42277C21719E6D (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814 (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_point, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Transform_set_position_mA1A817124BB41B685043DED2A9BA48CDF37C4156 (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_value, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_clamp_mB7233FC9D6C27522014C4E6D4E056D36CE82C97E_inline (float ___0_valueToClamp, float ___1_lowerBound, float ___2_upperBound, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_Normalize_mEF8349CC39674236CFC694189AFD36E31F89AC8F_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_value, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_up_m128AF3FDC820BF59D5DE86D973E7DE3F20C3AEBA_inline (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float SpriteShapeObjectPlacement_Angle_m133A7031202A395E8963E07B72900C9559763B6E (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_Euler_m9262AB29E3E9CE94EF71051F38A28E82AEC73F90_inline (float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Matrix4x4_get_rotation_m7E2C29FCB2AAFAE4D7B4FBD3563E9EDB53F5A8BB (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_op_Multiply_mCB375FCCC12A2EC8F9EB824A1BFB4453B58C2012_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_lhs, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Transform_set_rotation_m61340DE74726CF0F9946743A727C4D444397331D (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D SpriteShapeController_GetShapeControlPoints_m4A0BF704DB4274546156AC4085353536541B30D5 (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 SpriteShapeObjectPlacement_PlaceObjectInternal_m3936E149DD314A1669C8C3CA8652C68D8350361C (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_sp, int32_t ___1_ep, float ___2_t, NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D ___3_shapePoints, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float SpriteShapeObjectPlacement_GetDistance_m26F046CB844C933DD5EE6A5D744A857B8FB093FB (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, float ___0_dist, int32_t ___1_spoint, int32_t ___2_epoint, int32_t* ___3_start, int32_t* ___4_end, float* ___5_r, NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D ___6_shapePoints, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Spline_tD674213224F697425072FBF76AE3FD203AD2B818* SpriteShapeController_get_spline_m1266CB84F33024475FA4FC6C2F35E4E3E74AD6B9_inline (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Spline_GetPointCount_m9A872A9A4C7CA81296EF70F93D48B8C47A5F7415 (Spline_tD674213224F697425072FBF76AE3FD203AD2B818* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Spline_get_isOpenEnded_m09BD0EAEDB52B06A28C0D5718F63043791DC6861 (Spline_tD674213224F697425072FBF76AE3FD203AD2B818* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_GetSplinePointCount_mF27D6D3AAE57EF8C5A3C0FDC91A341E3BA3EE117 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_clamp_m9EABD008C8EAD9D150062ABE724D96FA2121EE1C_inline (int32_t ___0_valueToClamp, int32_t ___1_lowerBound, int32_t ___2_upperBound, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_endPoint_m62B77B64D9F7332D75A19F768B1CFF1FB919C040_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_LogWarning_m23033D7E2F0F298BE465B7F3A63CDF40A4EB70EB (RuntimeObject* ___0_message, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___1_context, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 SpriteShapeObjectPlacement_PlaceObject_m7FB81E5C890FECC6A79C3A46C6BC326B2C9A4D5E (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, Spline_tD674213224F697425072FBF76AE3FD203AD2B818* ___0_spline, int32_t ___1_sp, int32_t ___2_ep, bool* ___3_run, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Spline_GetPosition_m68F7EECA5140A4D6C0FAA8AB9F8DED9BF214CF9C (Spline_tD674213224F697425072FBF76AE3FD203AD2B818* __this, int32_t ___0_index, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Spline_GetRightTangent_m6008A3450C5E0D85D57FA8A1453670CBC5B280EF (Spline_tD674213224F697425072FBF76AE3FD203AD2B818* __this, int32_t ___0_index, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Spline_GetLeftTangent_m722F61220067D72DD8CDD817E9174F331778A398 (Spline_tD674213224F697425072FBF76AE3FD203AD2B818* __this, int32_t ___0_index, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 BezierUtility_ClosestPointOnCurve_m91458888AC7667493117C7BE8E339A404533656C (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_point, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_startPosition, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___2_endPosition, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___3_startTangent, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___4_endTangent, float ___5_sqrError, float* ___6_t, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Vector3_get_magnitude_mF0D6017E90B345F1F52D1CC564C640F1A847AF2D_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_startPoint_m2C880BECFF67C3478402FF2A88C8F5F5E2E60CA6_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_value, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_ratio_mED658B93A3A246178CCB30DEC877EA54DA1842EC_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, float ___0_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool SpriteShapeObjectPlacement_PlaceObjectOnHashChange_m71263E4A1E32BA74D19300AC80B4D9A544441692 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E (MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71* __this, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
inline void NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float ___1_rhs, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float4_t89D9A294E7A79BD81BFBDD18654508532958555E ModuleHandle_Tessellate_mDCFCA96AD66F268C584B76699ECF5632D0C0E352 (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___1_points, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___2_edges, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___3_outVertices, int32_t* ___4_outVertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___5_outIndices, int32_t* ___6_outIndexCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___7_outEdges, int32_t* ___8_outEdgeCount, bool ___9_runPlanarGraph, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) ;
inline void NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*, const RuntimeMethod*))NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_gshared)(__this, method);
}
inline void NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*, const RuntimeMethod*))NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_gshared)(__this, method);
}
inline void NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*, const RuntimeMethod*))NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_gshared)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Single_GetHashCode_mC3F1E099D1CF165C2D71FBCC5EF6A6792F9021D2 (float* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int64_t BitConverter_DoubleToInt64Bits_m4F42741818550F9956B5FBAF88C051F4DE5B0AE6_inline (double ___0_value, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_op_Subtraction_mB6036E9849D95650D6E73DA0D179CD7B61E696F2_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_lhs, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_length_m6A2B63D7A3B84261C2F7FCAA2CB382288A57D257_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Vector3_Magnitude_m21652D951393A3D7CE92CE40049A0E7F76544D1B_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_vector, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Multiply_m87BA7C578F96C8E49BB07088DAAC4649F83B0353_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_Internal_FromEulerRad_m66D4475341F53949471E6870FB5C5E4A5E9BA93E (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_euler, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Quaternion__ctor_m868FD60AA65DD5A8AC0C5DEB0608381A8D85FCD8_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974* __this, float ___0_x, float ___1_y, float ___2_z, float ___3_w, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_min_m02D43DF516544C279AF660EA4731449C82991849_inline (int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline (int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_dot_mE193D8880350D74CC8D63A0D53CDC5902F844AAD_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_x, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_sqrt_mEF31DE7BD0179009683C5D7B0C58E6571B30CF4A_inline (float ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Single_IsNaN_mFE637F6ECA9F7697CE8EFF56427858F4C5EDF75D_inline (float ___0_f, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t BitConverter_SingleToInt32Bits_mC760C7CFC89725E3CF68DC45BE3A9A42A7E7DA73_inline (float ___0_value, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Method Definition Index: 65928
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m3B0AC2339A8DE4BC31CEDD5BADA65B9D7949A349 (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74* L_0 = (U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74*)il2cpp_codegen_object_new(U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_mA91FE5EA2C14E43491278E311B2F74B7478EF999(L_0, NULL);
		((U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74_il2cpp_TypeInfo_var))->___U3CU3E9 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74_il2cpp_TypeInfo_var))->___U3CU3E9), (void*)L_0);
		return;
	}
}
// Method Definition Index: 65929
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mA91FE5EA2C14E43491278E311B2F74B7478EF999 (U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// Method Definition Index: 65930
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint16_t U3CU3Ec_U3CTessellateContourMainThreadU3Eb__155_0_m4DC5973A9C496EEA6F7E0098F7A5D14133CF8FA8 (U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74* __this, int32_t ___0_i, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1311>
		int32_t L_0 = ___0_i;
		return (uint16_t)((int32_t)(uint16_t)L_0);
	}
}
// Method Definition Index: 65931
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 U3CU3Ec_U3CTessellateContourMainThreadU3Eb__155_1_mF10AA4653D6AE7C5ECCE75B6EE424F6A82D6B37C (U3CU3Ec_tBCE2556A62FBB2630B0C191C01319B1FBE992F74* __this, ContourVertex_tCF411C2A25CB1E379D7566058ACD30AE23E7FC66 ___0_v, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1312>
		ContourVertex_tCF411C2A25CB1E379D7566058ACD30AE23E7FC66 L_0 = ___0_v;
		Vec3_t2DC07E9249C572CF68A4D54873B4038A68B77E74 L_1 = L_0.___Position;
		float L_2 = L_1.___X;
		ContourVertex_tCF411C2A25CB1E379D7566058ACD30AE23E7FC66 L_3 = ___0_v;
		Vec3_t2DC07E9249C572CF68A4D54873B4038A68B77E74 L_4 = L_3.___Position;
		float L_5 = L_4.___Y;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_6;
		memset((&L_6), 0, sizeof(L_6));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_6), L_2, L_5, NULL);
		return L_6;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
void UTessellator_0000017FU24PostfixBurstDelegate_Invoke_m3FE651BD796903A59B0486C44F86A6101BB31024_Multicast(UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, const RuntimeMethod* method)
{
	il2cpp_array_size_t length = __this->___delegates->max_length;
	Delegate_t** delegatesToInvoke = reinterpret_cast<Delegate_t**>(__this->___delegates->GetAddressAtUnchecked(0));
	for (il2cpp_array_size_t i = 0; i < length; i++)
	{
		UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* currentDelegate = reinterpret_cast<UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA*>(delegatesToInvoke[i]);
		typedef void (*FunctionPointerType) (RuntimeObject*, SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5*, int32_t, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*, int32_t, uint16_t*, int32_t*, uint8_t*, int32_t, int32_t*, int32_t, const RuntimeMethod*);
		((FunctionPointerType)currentDelegate->___invoke_impl)((Il2CppObject*)currentDelegate->___method_code, ___0_geom, ___1_maxCount, ___2_tessPoints, ___3_tessPointCount, ___4_indices, ___5_iCount, ___6_vertices, ___7_stride, ___8_vCount, ___9_label, reinterpret_cast<RuntimeMethod*>(currentDelegate->___method));
	}
}
void UTessellator_0000017FU24PostfixBurstDelegate_Invoke_m3FE651BD796903A59B0486C44F86A6101BB31024_OpenInst(UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, const RuntimeMethod* method)
{
	typedef void (*FunctionPointerType) (SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5*, int32_t, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*, int32_t, uint16_t*, int32_t*, uint8_t*, int32_t, int32_t*, int32_t, const RuntimeMethod*);
	((FunctionPointerType)__this->___method_ptr)(___0_geom, ___1_maxCount, ___2_tessPoints, ___3_tessPointCount, ___4_indices, ___5_iCount, ___6_vertices, ___7_stride, ___8_vCount, ___9_label, method);
}
void UTessellator_0000017FU24PostfixBurstDelegate_Invoke_m3FE651BD796903A59B0486C44F86A6101BB31024_OpenStatic(UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, const RuntimeMethod* method)
{
	typedef void (*FunctionPointerType) (SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5*, int32_t, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*, int32_t, uint16_t*, int32_t*, uint8_t*, int32_t, int32_t*, int32_t, const RuntimeMethod*);
	((FunctionPointerType)__this->___method_ptr)(___0_geom, ___1_maxCount, ___2_tessPoints, ___3_tessPointCount, ___4_indices, ___5_iCount, ___6_vertices, ___7_stride, ___8_vCount, ___9_label, method);
}
IL2CPP_EXTERN_C  void DelegatePInvokeWrapper_UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, const RuntimeMethod* method)
{
	typedef void (CDECL *PInvokeFunc)(SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5*, int32_t, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*, int32_t, uint16_t*, int32_t*, uint8_t*, int32_t, int32_t*, int32_t);
	PInvokeFunc il2cppPInvokeFunc = reinterpret_cast<PInvokeFunc>(il2cpp_codegen_get_reverse_pinvoke_function_ptr(__this));
	il2cppPInvokeFunc(___0_geom, ___1_maxCount, ___2_tessPoints, ___3_tessPointCount, ___4_indices, ___5_iCount, ___6_vertices, ___7_stride, ___8_vCount, ___9_label);

}
// Method Definition Index: 65932
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UTessellator_0000017FU24PostfixBurstDelegate__ctor_m7D82A379E92F612522917026D1FBB234A0299719 (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, RuntimeObject* ___0_p, intptr_t ___1_p, const RuntimeMethod* method) 
{
	__this->___method_ptr = (intptr_t)il2cpp_codegen_get_method_pointer((RuntimeMethod*)___1_p);
	__this->___method = ___1_p;
	__this->___m_target = ___0_p;
	Il2CppCodeGenWriteBarrier((void**)(&__this->___m_target), (void*)___0_p);
	int parameterCount = il2cpp_codegen_method_parameter_count((RuntimeMethod*)___1_p);
	__this->___method_code = (intptr_t)__this;
	if (MethodIsStatic((RuntimeMethod*)___1_p))
	{
		bool isOpen = parameterCount == 10;
		if (isOpen)
			__this->___invoke_impl = (intptr_t)&UTessellator_0000017FU24PostfixBurstDelegate_Invoke_m3FE651BD796903A59B0486C44F86A6101BB31024_OpenStatic;
		else
			{
				__this->___invoke_impl = __this->___method_ptr;
				__this->___method_code = (intptr_t)__this->___m_target;
			}
	}
	else
	{
		bool isOpen = parameterCount == 9;
		if (isOpen)
		{
			__this->___invoke_impl = (intptr_t)&UTessellator_0000017FU24PostfixBurstDelegate_Invoke_m3FE651BD796903A59B0486C44F86A6101BB31024_OpenInst;
		}
		else
		{
			if (___0_p == NULL)
				il2cpp_codegen_raise_exception(il2cpp_codegen_get_argument_exception(NULL, "Delegate to an instance method cannot have null 'this'."), NULL);
			__this->___invoke_impl = __this->___method_ptr;
			__this->___method_code = (intptr_t)__this->___m_target;
		}
	}
	__this->___extra_arg = (intptr_t)&UTessellator_0000017FU24PostfixBurstDelegate_Invoke_m3FE651BD796903A59B0486C44F86A6101BB31024_Multicast;
}
// Method Definition Index: 65933
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UTessellator_0000017FU24PostfixBurstDelegate_Invoke_m3FE651BD796903A59B0486C44F86A6101BB31024 (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, const RuntimeMethod* method) 
{
	typedef void (*FunctionPointerType) (RuntimeObject*, SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5*, int32_t, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*, int32_t, uint16_t*, int32_t*, uint8_t*, int32_t, int32_t*, int32_t, const RuntimeMethod*);
	((FunctionPointerType)__this->___invoke_impl)((Il2CppObject*)__this->___method_code, ___0_geom, ___1_maxCount, ___2_tessPoints, ___3_tessPointCount, ___4_indices, ___5_iCount, ___6_vertices, ___7_stride, ___8_vCount, ___9_label, reinterpret_cast<RuntimeMethod*>(__this->___method));
}
// Method Definition Index: 65934
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* UTessellator_0000017FU24PostfixBurstDelegate_BeginInvoke_m098909B481B8513DBEABBFAF8389B36B3B207D98 (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, AsyncCallback_t7FEF460CBDCFB9C5FA2EF776984778B9A4145F4C* ___10_p, RuntimeObject* ___11_p, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Allocator_t996642592271AAD9EE688F142741D512C07B5824_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	void *__d_args[11] = {0};
	__d_args[0] = Box(SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5_il2cpp_TypeInfo_var, &*___0_geom);
	__d_args[1] = Box(il2cpp_defaults.int32_class, &___1_maxCount);
	__d_args[2] = ___2_tessPoints;
	__d_args[3] = Box(il2cpp_defaults.int32_class, &___3_tessPointCount);
	__d_args[4] = ___4_indices;
	__d_args[5] = Box(il2cpp_defaults.int32_class, &*___5_iCount);
	__d_args[6] = ___6_vertices;
	__d_args[7] = Box(il2cpp_defaults.int32_class, &___7_stride);
	__d_args[8] = Box(il2cpp_defaults.int32_class, &*___8_vCount);
	__d_args[9] = Box(Allocator_t996642592271AAD9EE688F142741D512C07B5824_il2cpp_TypeInfo_var, &___9_label);
	return (RuntimeObject*)il2cpp_codegen_delegate_begin_invoke((RuntimeDelegate*)__this, __d_args, (RuntimeDelegate*)___10_p, (RuntimeObject*)___11_p);
}
// Method Definition Index: 65935
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UTessellator_0000017FU24PostfixBurstDelegate_EndInvoke_m0CA934E4E8F4AF159D45C6766236E3C036AA0304 (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* __this, RuntimeObject* ___0_p, const RuntimeMethod* method) 
{
	il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___0_p, 0);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Method Definition Index: 65936
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UTessellator_0000017FU24BurstDirectCall_GetFunctionPointerDiscard_m674170764EDF0A0753BD85F5B4326892F27ABA44 (intptr_t* ___0_p, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&BurstCompiler_CompileFunctionPointer_TisUTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA_m185061C1CB9EC862782431884C54DCBB4BA2A702_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&FunctionPointer_1_get_Value_mCBDE3C3B018EFC1FB10C35410FBD998F12C042F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteShapeGenerator_UTessellator_mA975B9F66E80F2334124BFADD19F331AB2F6E90D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	FunctionPointer_1_tE9B0E7B7584968B2ED8D94E976B6AB8C67D4E4D4 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		intptr_t L_0 = ((UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_StaticFields*)il2cpp_codegen_static_fields_for(UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_il2cpp_TypeInfo_var))->___Pointer;
		if (L_0)
		{
			goto IL_002a;
		}
	}
	{
		UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA* L_1 = (UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA*)il2cpp_codegen_object_new(UTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA_il2cpp_TypeInfo_var);
		UTessellator_0000017FU24PostfixBurstDelegate__ctor_m7D82A379E92F612522917026D1FBB234A0299719(L_1, NULL, (intptr_t)((void*)SpriteShapeGenerator_UTessellator_mA975B9F66E80F2334124BFADD19F331AB2F6E90D_RuntimeMethod_var), NULL);
		il2cpp_codegen_runtime_class_init_inline(BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_il2cpp_TypeInfo_var);
		FunctionPointer_1_tE9B0E7B7584968B2ED8D94E976B6AB8C67D4E4D4 L_2;
		L_2 = BurstCompiler_CompileFunctionPointer_TisUTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA_m185061C1CB9EC862782431884C54DCBB4BA2A702(L_1, BurstCompiler_CompileFunctionPointer_TisUTessellator_0000017FU24PostfixBurstDelegate_tDF79A7EB1C33923D599FF1D39F29EDFDEC4E47BA_m185061C1CB9EC862782431884C54DCBB4BA2A702_RuntimeMethod_var);
		V_0 = L_2;
		intptr_t L_3;
		L_3 = FunctionPointer_1_get_Value_mCBDE3C3B018EFC1FB10C35410FBD998F12C042F2_inline((&V_0), FunctionPointer_1_get_Value_mCBDE3C3B018EFC1FB10C35410FBD998F12C042F2_RuntimeMethod_var);
		((UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_StaticFields*)il2cpp_codegen_static_fields_for(UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_il2cpp_TypeInfo_var))->___Pointer = L_3;
	}

IL_002a:
	{
		intptr_t* L_4 = ___0_p;
		intptr_t L_5 = ((UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_StaticFields*)il2cpp_codegen_static_fields_for(UTessellator_0000017FU24BurstDirectCall_t10E2F0FFAA6320EDA9200880AEAD6EC648617280_il2cpp_TypeInfo_var))->___Pointer;
		*((intptr_t*)L_4) = (intptr_t)L_5;
		return;
	}
}
// Method Definition Index: 65937
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR intptr_t UTessellator_0000017FU24BurstDirectCall_GetFunctionPointer_m5DDBAB15141B65F9C34F7A02735B490B7CB79DFB (const RuntimeMethod* method) 
{
	intptr_t V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		V_0 = ((intptr_t)0);
		UTessellator_0000017FU24BurstDirectCall_GetFunctionPointerDiscard_m674170764EDF0A0753BD85F5B4326892F27ABA44((&V_0), NULL);
		intptr_t L_0 = V_0;
		return L_0;
	}
}
// Method Definition Index: 65938
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UTessellator_0000017FU24BurstDirectCall_Invoke_mA24AF835EA088D43CAC380DDCAB35C8BD81A688C (SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	intptr_t V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		il2cpp_codegen_runtime_class_init_inline(BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_il2cpp_TypeInfo_var);
		bool L_0;
		L_0 = BurstCompiler_get_IsEnabled_m55FDBCB2279A83AC8926260034F870E3A11116C7(NULL);
		if (!L_0)
		{
			goto IL_002d;
		}
	}
	{
		intptr_t L_1;
		L_1 = UTessellator_0000017FU24BurstDirectCall_GetFunctionPointer_m5DDBAB15141B65F9C34F7A02735B490B7CB79DFB(NULL);
		V_0 = L_1;
		intptr_t L_2 = V_0;
		if (!L_2)
		{
			goto IL_002d;
		}
	}
	{
		SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* L_3 = ___0_geom;
		int32_t L_4 = ___1_maxCount;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_5 = ___2_tessPoints;
		int32_t L_6 = ___3_tessPointCount;
		uint16_t* L_7 = ___4_indices;
		int32_t* L_8 = ___5_iCount;
		uint8_t* L_9 = ___6_vertices;
		int32_t L_10 = ___7_stride;
		int32_t* L_11 = ___8_vCount;
		int32_t L_12 = ___9_label;
		intptr_t L_13 = V_0;
		typedef void (CDECL *func_L_14)(SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5*,int32_t,float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*,int32_t,uint16_t*,int32_t*,uint8_t*,int32_t,int32_t*,int32_t);
		((func_L_14)L_13)(L_3, L_4, L_5, L_6, L_7, L_8, L_9, L_10, L_11, L_12);
		return;
	}

IL_002d:
	{
		SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* L_15 = ___0_geom;
		int32_t L_16 = ___1_maxCount;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_17 = ___2_tessPoints;
		int32_t L_18 = ___3_tessPointCount;
		uint16_t* L_19 = ___4_indices;
		int32_t* L_20 = ___5_iCount;
		uint8_t* L_21 = ___6_vertices;
		int32_t L_22 = ___7_stride;
		int32_t* L_23 = ___8_vCount;
		int32_t L_24 = ___9_label;
		SpriteShapeGenerator_UTessellatorU24BurstManaged_m6F4F57B7363784CE1724AE26829C356319E88118_inline(L_15, L_16, L_17, L_18, L_19, L_20, L_21, L_22, L_23, L_24, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Method Definition Index: 65941
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t SpriteShapeGeometryCreator_GetVersion_m44860C0EE661F0B0B7D145D084BA7D5CE6C7ACA8 (SpriteShapeGeometryCreator_t7A84B10A6429A625610D783C12A86ED5F1C515C4* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGeometryCreator.cs:39>
		int32_t L_0;
		L_0 = Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A(__this, NULL);
		return L_0;
	}
}
// Method Definition Index: 65942
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeGeometryCreator__ctor_m11995DD5FE4D69A420FABBD8AE3DB243E9D4EF7B (SpriteShapeGeometryCreator_t7A84B10A6429A625610D783C12A86ED5F1C515C4* __this, const RuntimeMethod* method) 
{
	{
		ScriptableObject__ctor_mD037FDB0B487295EA47F79A4DB1BF1846C9087FF(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Method Definition Index: 65944
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t SpriteShapeGeometryModifier_GetVersion_m279A107B00A417E5058A6456CEAA750C66C88D89 (SpriteShapeGeometryModifier_tBCAFA8CB38E611DA5EB0D1F2E6DD67762302369F* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGeometryModifier.cs:33>
		int32_t L_0;
		L_0 = Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A(__this, NULL);
		return L_0;
	}
}
// Method Definition Index: 65945
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeGeometryModifier__ctor_mC8B2D08FC71266F54041FAD12592B2009883C48E (SpriteShapeGeometryModifier_tBCAFA8CB38E611DA5EB0D1F2E6DD67762302369F* __this, const RuntimeMethod* method) 
{
	{
		ScriptableObject__ctor_mD037FDB0B487295EA47F79A4DB1BF1846C9087FF(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Method Definition Index: 65946
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool SpriteShapeObjectPlacement_get_setNormal_mDF4F4E07D5CD4B8A7D5A3B1A280BB21FBD8A0567 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:61>
		bool L_0 = __this->___m_SetNormal;
		return L_0;
	}
}
// Method Definition Index: 65947
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_setNormal_mC372153584297F251B6C0010110900584F0C7FC4 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, bool ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:62>
		bool L_0 = ___0_value;
		__this->___m_SetNormal = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:62>
		return;
	}
}
// Method Definition Index: 65948
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_get_mode_mC07CCEC65A4CF7075CE09754A2B503D3926E428E (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:70>
		int32_t L_0 = __this->___m_Mode;
		return L_0;
	}
}
// Method Definition Index: 65949
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_mode_m4F946059DDF7E8EEBC818BE0ECCE59C3A7193F2F (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:71>
		int32_t L_0 = ___0_value;
		__this->___m_Mode = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:71>
		return;
	}
}
// Method Definition Index: 65950
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float SpriteShapeObjectPlacement_get_ratio_m1AD37D2E67595975F88822C70707DF5EFB8B5F3B (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:79>
		float L_0 = __this->___m_Ratio;
		return L_0;
	}
}
// Method Definition Index: 65951
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_ratio_mED658B93A3A246178CCB30DEC877EA54DA1842EC (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, float ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:80>
		float L_0 = ___0_value;
		__this->___m_Ratio = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:80>
		return;
	}
}
// Method Definition Index: 65952
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:88>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_0 = __this->___m_SpriteShapeController;
		return L_0;
	}
}
// Method Definition Index: 65953
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_spriteShapeController_m20610E17F7CF90F7DA016ED8D7F3E335AACE7F01 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:89>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_0 = ___0_value;
		__this->___m_SpriteShapeController = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_SpriteShapeController), (void*)L_0);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:89>
		return;
	}
}
// Method Definition Index: 65954
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_get_startPoint_m1C539FDCDDB00A0918771704D55D113549A08D12 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:97>
		int32_t L_0 = __this->___m_StartPoint;
		return L_0;
	}
}
// Method Definition Index: 65955
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_startPoint_m2C880BECFF67C3478402FF2A88C8F5F5E2E60CA6 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:98>
		int32_t L_0 = ___0_value;
		__this->___m_StartPoint = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:98>
		return;
	}
}
// Method Definition Index: 65956
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_get_endPoint_m1183FA74B1AF9A9806EC708DC9AB9FC183983335 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:106>
		int32_t L_0 = __this->___m_EndPoint;
		return L_0;
	}
}
// Method Definition Index: 65957
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_endPoint_m62B77B64D9F7332D75A19F768B1CFF1FB919C040 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:107>
		int32_t L_0 = ___0_value;
		__this->___m_EndPoint = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:107>
		return;
	}
}
// Method Definition Index: 65958
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool SpriteShapeObjectPlacement_PlaceObjectOnHashChange_m71263E4A1E32BA74D19300AC80B4D9A544441692 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* V_2 = NULL;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_3;
	memset((&V_3), 0, sizeof(V_3));
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 V_4;
	memset((&V_4), 0, sizeof(V_4));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_5;
	memset((&V_5), 0, sizeof(V_5));
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 V_6;
	memset((&V_6), 0, sizeof(V_6));
	int32_t V_7 = 0;
	double V_8 = 0.0;
	int32_t G_B4_0 = 0;
	int32_t G_B3_0 = 0;
	int32_t G_B5_0 = 0;
	int32_t G_B5_1 = 0;
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:112>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_0;
		L_0 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_1;
		L_1 = Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605((Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, L_0, NULL);
		if (!L_1)
		{
			goto IL_0010;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:113>
		return (bool)0;
	}

IL_0010:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:117>
		V_0 = 0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:118>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_2;
		L_2 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_2);
		int32_t L_3;
		L_3 = SpriteShapeController_get_splineHashCode_m5FD24A66B300EA0F8E1A1B0E5100ED3D0AA8FB98_inline(L_2, NULL);
		V_1 = ((int32_t)(((int32_t)-2128831035)^L_3));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:119>
		int32_t L_4 = V_1;
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_5;
		L_5 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_5);
		int32_t L_6;
		L_6 = SpriteShapeController_get_spriteShapeHashCode_mF2D6ABCAF590DFC5A0461E61A8B78356FD2FB520_inline(L_5, NULL);
		V_1 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_4, ((int32_t)16777619)))^L_6));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:120>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_7;
		L_7 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_7);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_8;
		L_8 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(L_7, NULL);
		NullCheck(L_8);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_9;
		L_9 = GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56(L_8, NULL);
		V_2 = L_9;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:121>
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_10;
		L_10 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(__this, NULL);
		NullCheck(L_10);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_11;
		L_11 = GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56(L_10, NULL);
		NullCheck(L_11);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		L_12 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_11, NULL);
		V_3 = L_12;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:122>
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_13;
		L_13 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(__this, NULL);
		NullCheck(L_13);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_14;
		L_14 = GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56(L_13, NULL);
		NullCheck(L_14);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_15;
		L_15 = Transform_get_rotation_m32AF40CA0D50C797DA639A696F8EAEC7524C179C(L_14, NULL);
		V_4 = L_15;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:123>
		int32_t L_16 = V_1;
		bool L_17;
		L_17 = SpriteShapeObjectPlacement_get_setNormal_mDF4F4E07D5CD4B8A7D5A3B1A280BB21FBD8A0567_inline(__this, NULL);
		if (L_17)
		{
			G_B4_0 = ((int32_t)il2cpp_codegen_multiply(L_16, ((int32_t)16777619)));
			goto IL_007e;
		}
		G_B3_0 = ((int32_t)il2cpp_codegen_multiply(L_16, ((int32_t)16777619)));
	}
	{
		G_B5_0 = 0;
		G_B5_1 = G_B3_0;
		goto IL_007f;
	}

IL_007e:
	{
		G_B5_0 = 1;
		G_B5_1 = G_B4_0;
	}

IL_007f:
	{
		V_1 = ((int32_t)(G_B5_1^G_B5_0));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:124>
		int32_t L_18 = V_1;
		int32_t L_19;
		L_19 = SpriteShapeObjectPlacement_get_startPoint_m1C539FDCDDB00A0918771704D55D113549A08D12_inline(__this, NULL);
		V_1 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_18, ((int32_t)16777619)))^L_19));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:125>
		int32_t L_20 = V_1;
		int32_t L_21;
		L_21 = SpriteShapeObjectPlacement_get_endPoint_m1183FA74B1AF9A9806EC708DC9AB9FC183983335_inline(__this, NULL);
		V_1 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_20, ((int32_t)16777619)))^L_21));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:126>
		int32_t L_22 = V_1;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_23 = V_2;
		NullCheck(L_23);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_24;
		L_24 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_23, NULL);
		V_5 = L_24;
		int32_t L_25;
		L_25 = Vector3_GetHashCode_mB08429DC931A85BD29CE11B9ABC77DE7E0E46327_inline((&V_5), NULL);
		V_1 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_22, ((int32_t)16777619)))^L_25));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:127>
		int32_t L_26 = V_1;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_27 = V_2;
		NullCheck(L_27);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_28;
		L_28 = Transform_get_rotation_m32AF40CA0D50C797DA639A696F8EAEC7524C179C(L_27, NULL);
		V_6 = L_28;
		int32_t L_29;
		L_29 = Quaternion_GetHashCode_m5F55C34C98E437376595E722BE4EB8A70434F049_inline((&V_6), NULL);
		V_1 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_26, ((int32_t)16777619)))^L_29));
	}

IL_00db:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:132>
		int32_t L_30 = V_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_31 = V_3;
		float L_32 = L_31.___x;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		double L_33;
		L_33 = bankers_round(((double)((float)il2cpp_codegen_multiply(L_32, (1000.0f)))));
		V_8 = L_33;
		int32_t L_34;
		L_34 = Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline((&V_8), NULL);
		V_7 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_30, ((int32_t)16777619)))^L_34));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:133>
		int32_t L_35 = V_7;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_36 = V_3;
		float L_37 = L_36.___y;
		double L_38;
		L_38 = bankers_round(((double)((float)il2cpp_codegen_multiply(L_37, (1000.0f)))));
		V_8 = L_38;
		int32_t L_39;
		L_39 = Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline((&V_8), NULL);
		V_7 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_35, ((int32_t)16777619)))^L_39));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:134>
		int32_t L_40 = V_7;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_41 = V_3;
		float L_42 = L_41.___z;
		double L_43;
		L_43 = bankers_round(((double)((float)il2cpp_codegen_multiply(L_42, (1000.0f)))));
		V_8 = L_43;
		int32_t L_44;
		L_44 = Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline((&V_8), NULL);
		V_7 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_40, ((int32_t)16777619)))^L_44));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:135>
		int32_t L_45 = V_7;
		float L_46;
		L_46 = SpriteShapeObjectPlacement_get_ratio_m1AD37D2E67595975F88822C70707DF5EFB8B5F3B_inline(__this, NULL);
		double L_47;
		L_47 = bankers_round(((double)((float)il2cpp_codegen_multiply(L_46, (1000.0f)))));
		V_8 = L_47;
		int32_t L_48;
		L_48 = Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline((&V_8), NULL);
		V_7 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_45, ((int32_t)16777619)))^L_48));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:136>
		int32_t L_49 = V_7;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_50 = V_4;
		float L_51 = L_50.___x;
		double L_52;
		L_52 = bankers_round(((double)((float)il2cpp_codegen_multiply(L_51, (1000.0f)))));
		V_8 = L_52;
		int32_t L_53;
		L_53 = Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline((&V_8), NULL);
		V_7 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_49, ((int32_t)16777619)))^L_53));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:137>
		int32_t L_54 = V_7;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_55 = V_4;
		float L_56 = L_55.___y;
		double L_57;
		L_57 = bankers_round(((double)((float)il2cpp_codegen_multiply(L_56, (1000.0f)))));
		V_8 = L_57;
		int32_t L_58;
		L_58 = Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline((&V_8), NULL);
		V_7 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_54, ((int32_t)16777619)))^L_58));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:138>
		int32_t L_59 = V_7;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_60 = V_4;
		float L_61 = L_60.___z;
		double L_62;
		L_62 = bankers_round(((double)((float)il2cpp_codegen_multiply(L_61, (1000.0f)))));
		V_8 = L_62;
		int32_t L_63;
		L_63 = Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline((&V_8), NULL);
		V_7 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_59, ((int32_t)16777619)))^L_63));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:139>
		int32_t L_64 = V_7;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_65 = V_4;
		float L_66 = L_65.___w;
		double L_67;
		L_67 = bankers_round(((double)((float)il2cpp_codegen_multiply(L_66, (1000.0f)))));
		V_8 = L_67;
		int32_t L_68;
		L_68 = Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline((&V_8), NULL);
		V_7 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_64, ((int32_t)16777619)))^L_68));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:141>
		int32_t L_69 = __this->___m_ActiveHashCode;
		int32_t L_70 = V_7;
		if ((((int32_t)L_69) == ((int32_t)L_70)))
		{
			goto IL_0237;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:143>
		bool L_71;
		L_71 = SpriteShapeObjectPlacement_Place_m67C08775427481BF5175EF5BA5455F6B837140E9(__this, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:144>
		int32_t L_72 = V_7;
		__this->___m_ActiveHashCode = L_72;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:145>
		if (!L_71)
		{
			goto IL_0237;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:152>
		int32_t L_73 = V_0;
		int32_t L_74 = L_73;
		V_0 = ((int32_t)il2cpp_codegen_add(L_74, 1));
		il2cpp_codegen_runtime_class_init_inline(SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var);
		int32_t L_75 = ((SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_StaticFields*)il2cpp_codegen_static_fields_for(SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var))->___kMaxIteration;
		if ((((int32_t)L_74) < ((int32_t)L_75)))
		{
			goto IL_00db;
		}
	}

IL_0237:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:155>
		return (bool)0;
	}
}
// Method Definition Index: 65959
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float SpriteShapeObjectPlacement_Angle_m133A7031202A395E8963E07B72900C9559763B6E (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:160>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1 = ___1_b;
		float L_2;
		L_2 = Vector3_Dot_mBB86BB940AA0A32FA7D3C02AC42E5BC7095A5D52_inline(L_0, L_1, NULL);
		V_0 = L_2;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:161>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3 = ___0_a;
		float L_4 = L_3.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_5 = ___1_b;
		float L_6 = L_5.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_7 = ___1_b;
		float L_8 = L_7.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_9 = ___0_a;
		float L_10 = L_9.___y;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:162>
		float L_11 = V_0;
		float L_12;
		L_12 = atan2f(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_multiply(L_4, L_6)), ((float)il2cpp_codegen_multiply(L_8, L_10)))), L_11);
		return ((float)il2cpp_codegen_multiply(L_12, (57.2957802f)));
	}
}
// Method Definition Index: 65960
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float SpriteShapeObjectPlacement_GetDistance_m26F046CB844C933DD5EE6A5D744A857B8FB093FB (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, float ___0_dist, int32_t ___1_spoint, int32_t ___2_epoint, int32_t* ___3_start, int32_t* ___4_end, float* ___5_r, NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D ___6_shapePoints, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&BezierUtility_t450F38689B5013A23432043C5922D64496EF5E60_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	float V_1 = 0.0f;
	float V_2 = 0.0f;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 V_6;
	memset((&V_6), 0, sizeof(V_6));
	ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 V_7;
	memset((&V_7), 0, sizeof(V_7));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_8;
	memset((&V_8), 0, sizeof(V_8));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_9;
	memset((&V_9), 0, sizeof(V_9));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_10;
	memset((&V_10), 0, sizeof(V_10));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_11;
	memset((&V_11), 0, sizeof(V_11));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_12;
	memset((&V_12), 0, sizeof(V_12));
	float V_13 = 0.0f;
	float V_14 = 0.0f;
	bool V_15 = false;
	int32_t V_16 = 0;
	float V_17 = 0.0f;
	float V_18 = 0.0f;
	float V_19 = 0.0f;
	int32_t* G_B7_0 = NULL;
	int32_t* G_B6_0 = NULL;
	int32_t G_B8_0 = 0;
	int32_t* G_B8_1 = NULL;
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:166>
		int32_t* L_0 = ___3_start;
		*((int32_t*)L_0) = (int32_t)(-1);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:167>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_1;
		L_1 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_1);
		int32_t L_2;
		L_2 = SpriteShapeController_get_splineDetail_mB03C316DE81143E38A30C15C339D36DAD7C56E33_inline(L_1, NULL);
		V_0 = L_2;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:168>
		V_1 = (0.0f);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:169>
		int32_t L_3 = V_0;
		V_2 = ((float)((int32_t)il2cpp_codegen_subtract(L_3, 1)));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:170>
		int32_t L_4;
		L_4 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___6_shapePoints))->___m_Length);
		V_3 = L_4;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:172>
		int32_t L_5 = ___1_spoint;
		V_4 = L_5;
		goto IL_011b;
	}

IL_002b:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:174>
		int32_t L_6 = V_4;
		V_5 = ((int32_t)il2cpp_codegen_add(L_6, 1));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:175>
		int32_t L_7 = V_5;
		int32_t L_8 = V_3;
		if ((!(((uint32_t)L_7) == ((uint32_t)L_8))))
		{
			goto IL_0039;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:175>
		V_5 = 0;
	}

IL_0039:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:176>
		int32_t L_9 = V_4;
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_10;
		L_10 = IL2CPP_NATIVEARRAY_GET_ITEM(ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5, ((&___6_shapePoints))->___m_Buffer, L_9);
		V_6 = L_10;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:177>
		int32_t L_11 = V_5;
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_12;
		L_12 = IL2CPP_NATIVEARRAY_GET_ITEM(ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5, ((&___6_shapePoints))->___m_Buffer, L_11);
		V_7 = L_12;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:179>
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_13 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_14 = L_13.___position;
		V_8 = L_14;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:180>
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_15 = V_7;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_16 = L_15.___position;
		V_9 = L_16;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:181>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_17 = V_8;
		V_10 = L_17;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:182>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_18 = V_8;
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_19 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_20 = L_19.___rightTangent;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_21;
		L_21 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_18, L_20, NULL);
		V_11 = L_21;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:183>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_22 = V_9;
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_23 = V_7;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_24 = L_23.___leftTangent;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_25;
		L_25 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_22, L_24, NULL);
		V_12 = L_25;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:184>
		V_13 = (0.0f);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:185>
		V_14 = (0.0f);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:186>
		V_15 = (bool)0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:188>
		float L_26 = ___0_dist;
		if ((((float)L_26) == ((float)(0.0f))))
		{
			goto IL_00be;
		}
	}
	{
		float L_27 = ___0_dist;
		float L_28 = V_1;
		if ((!(((float)L_27) > ((float)L_28))))
		{
			goto IL_00be;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:190>
		int32_t* L_29 = ___3_start;
		int32_t L_30 = V_4;
		*((int32_t*)L_29) = (int32_t)L_30;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:191>
		int32_t* L_31 = ___4_end;
		int32_t L_32 = V_4;
		int32_t L_33 = V_3;
		if ((((int32_t)((int32_t)il2cpp_codegen_add(L_32, 1))) == ((int32_t)L_33)))
		{
			G_B7_0 = L_31;
			goto IL_00b6;
		}
		G_B6_0 = L_31;
	}
	{
		int32_t L_34 = V_4;
		G_B8_0 = ((int32_t)il2cpp_codegen_add(L_34, 1));
		G_B8_1 = G_B6_0;
		goto IL_00b7;
	}

IL_00b6:
	{
		G_B8_0 = 0;
		G_B8_1 = G_B7_0;
	}

IL_00b7:
	{
		*((int32_t*)G_B8_1) = (int32_t)G_B8_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:192>
		float L_35 = V_1;
		V_14 = L_35;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:193>
		V_15 = (bool)1;
	}

IL_00be:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:196>
		V_16 = 1;
		goto IL_00fe;
	}

IL_00c3:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:198>
		int32_t L_36 = V_16;
		float L_37 = V_2;
		V_17 = ((float)(((float)L_36)/L_37));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:199>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_38 = V_11;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_39 = V_8;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_40 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_41 = V_12;
		float L_42 = V_17;
		il2cpp_codegen_runtime_class_init_inline(BezierUtility_t450F38689B5013A23432043C5922D64496EF5E60_il2cpp_TypeInfo_var);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_43;
		L_43 = BezierUtility_BezierPoint_m58FBF49282434261BFE28A39F3C891889F6FAF54(L_38, L_39, L_40, L_41, L_42, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:200>
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_44;
		L_44 = float3_op_Implicit_mE1831A3AC179B7EB3236F8202EC8DD5CE05376AB(L_43, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_45 = V_10;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_46;
		L_46 = float3_op_Implicit_mE1831A3AC179B7EB3236F8202EC8DD5CE05376AB(L_45, NULL);
		float L_47;
		L_47 = math_distance_m516495927BCF37E20FFA3E99C821062D329DFFF8_inline(L_44, L_46, NULL);
		V_18 = L_47;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:201>
		float L_48 = V_13;
		float L_49 = V_18;
		V_13 = ((float)il2cpp_codegen_add(L_48, L_49));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:202>
		float L_50 = V_1;
		float L_51 = V_18;
		V_1 = ((float)il2cpp_codegen_add(L_50, L_51));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:196>
		int32_t L_52 = V_16;
		V_16 = ((int32_t)il2cpp_codegen_add(L_52, 1));
	}

IL_00fe:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:196>
		int32_t L_53 = V_16;
		int32_t L_54 = V_0;
		if ((((int32_t)L_53) < ((int32_t)L_54)))
		{
			goto IL_00c3;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:205>
		bool L_55 = V_15;
		if (!L_55)
		{
			goto IL_0115;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:207>
		float L_56 = ___0_dist;
		float L_57 = V_14;
		V_19 = ((float)il2cpp_codegen_subtract(L_56, L_57));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:208>
		float* L_58 = ___5_r;
		float L_59 = V_19;
		float L_60 = V_13;
		*((float*)L_58) = (float)((float)(L_59/L_60));
	}

IL_0115:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:172>
		int32_t L_61 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_61, 1));
	}

IL_011b:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:172>
		int32_t L_62 = V_4;
		int32_t L_63 = ___2_epoint;
		if ((((int32_t)L_62) < ((int32_t)L_63)))
		{
			goto IL_002b;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:211>
		float L_64 = V_1;
		return L_64;
	}
}
// Method Definition Index: 65961
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 SpriteShapeObjectPlacement_PlaceObjectInternal_m3936E149DD314A1669C8C3CA8652C68D8350361C (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_sp, int32_t ___1_ep, float ___2_t, NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D ___3_shapePoints, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&BezierUtility_t450F38689B5013A23432043C5922D64496EF5E60_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_1;
	memset((&V_1), 0, sizeof(V_1));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_2;
	memset((&V_2), 0, sizeof(V_2));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_3;
	memset((&V_3), 0, sizeof(V_3));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_4;
	memset((&V_4), 0, sizeof(V_4));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_5;
	memset((&V_5), 0, sizeof(V_5));
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 V_6;
	memset((&V_6), 0, sizeof(V_6));
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* V_7 = NULL;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_8;
	memset((&V_8), 0, sizeof(V_8));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_9;
	memset((&V_9), 0, sizeof(V_9));
	float V_10 = 0.0f;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_11;
	memset((&V_11), 0, sizeof(V_11));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_12;
	memset((&V_12), 0, sizeof(V_12));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_13;
	memset((&V_13), 0, sizeof(V_13));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_14;
	memset((&V_14), 0, sizeof(V_14));
	float V_15 = 0.0f;
	float V_16 = 0.0f;
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 V_17;
	memset((&V_17), 0, sizeof(V_17));
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:216>
		int32_t L_0 = ___1_ep;
		int32_t L_1;
		L_1 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___3_shapePoints))->___m_Length);
		___1_ep = ((int32_t)(L_0%L_1));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:217>
		int32_t L_2 = ___0_sp;
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5, ((&___3_shapePoints))->___m_Buffer, L_2);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = L_3.___position;
		V_0 = L_4;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:218>
		int32_t L_5 = ___1_ep;
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5, ((&___3_shapePoints))->___m_Buffer, L_5);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_7 = L_6.___position;
		V_1 = L_7;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:219>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = V_0;
		int32_t L_9 = ___0_sp;
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_10;
		L_10 = IL2CPP_NATIVEARRAY_GET_ITEM(ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5, ((&___3_shapePoints))->___m_Buffer, L_9);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_11 = L_10.___rightTangent;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		L_12 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_8, L_11, NULL);
		V_2 = L_12;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:220>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_1;
		int32_t L_14 = ___1_ep;
		ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5 L_15;
		L_15 = IL2CPP_NATIVEARRAY_GET_ITEM(ShapeControlPoint_tFB166AFC7B226867782300A7448C406D6DE6F8F5, ((&___3_shapePoints))->___m_Buffer, L_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_16 = L_15.___leftTangent;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_17;
		L_17 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_13, L_16, NULL);
		V_3 = L_17;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:221>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_18 = V_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_19 = V_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_20 = V_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_21 = V_3;
		float L_22 = ___2_t;
		il2cpp_codegen_runtime_class_init_inline(BezierUtility_t450F38689B5013A23432043C5922D64496EF5E60_il2cpp_TypeInfo_var);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_23;
		L_23 = BezierUtility_BezierPoint_m58FBF49282434261BFE28A39F3C891889F6FAF54(L_18, L_19, L_20, L_21, L_22, NULL);
		V_4 = L_23;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:222>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_24 = V_4;
		float L_25 = L_24.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_26 = V_4;
		float L_27 = L_26.___y;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_5), L_25, L_27, (0.0f), NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:223>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_28;
		L_28 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_28);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_29;
		L_29 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(L_28, NULL);
		NullCheck(L_29);
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 L_30;
		L_30 = Transform_get_localToWorldMatrix_m5D35188766856338DD21DE756F42277C21719E6D(L_29, NULL);
		V_6 = L_30;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:224>
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_31;
		L_31 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(__this, NULL);
		NullCheck(L_31);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_32;
		L_32 = GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56(L_31, NULL);
		V_7 = L_32;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:225>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_33 = V_5;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_34;
		L_34 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814((&V_6), L_33, NULL);
		V_8 = L_34;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:226>
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_35 = V_7;
		NullCheck(L_35);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_36;
		L_36 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_35, NULL);
		V_9 = L_36;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:227>
		int32_t L_37 = __this->___m_Mode;
		if (L_37)
		{
			goto IL_00c0;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:228>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_38 = V_8;
		float L_39 = L_38.___y;
		(&V_9)->___y = L_39;
		goto IL_00c4;
	}

IL_00c0:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:230>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_40 = V_8;
		V_9 = L_40;
	}

IL_00c4:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:231>
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_41 = V_7;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_42 = V_9;
		NullCheck(L_41);
		Transform_set_position_mA1A817124BB41B685043DED2A9BA48CDF37C4156(L_41, L_42, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:233>
		bool L_43;
		L_43 = SpriteShapeObjectPlacement_get_setNormal_mDF4F4E07D5CD4B8A7D5A3B1A280BB21FBD8A0567_inline(__this, NULL);
		if (!L_43)
		{
			goto IL_01f2;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:235>
		float L_44 = ___2_t;
		float L_45;
		L_45 = math_clamp_mB7233FC9D6C27522014C4E6D4E056D36CE82C97E_inline(L_44, (0.00200000009f), (0.998000026f), NULL);
		V_10 = L_45;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:236>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_46 = V_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_47 = V_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_48 = V_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_49 = V_3;
		float L_50 = V_10;
		il2cpp_codegen_runtime_class_init_inline(BezierUtility_t450F38689B5013A23432043C5922D64496EF5E60_il2cpp_TypeInfo_var);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_51;
		L_51 = BezierUtility_BezierPoint_m58FBF49282434261BFE28A39F3C891889F6FAF54(L_46, L_47, L_48, L_49, ((float)il2cpp_codegen_subtract(L_50, (0.00100000005f))), NULL);
		V_11 = L_51;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:237>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_52 = V_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_53 = V_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_54 = V_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_55 = V_3;
		float L_56 = V_10;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_57;
		L_57 = BezierUtility_BezierPoint_m58FBF49282434261BFE28A39F3C891889F6FAF54(L_52, L_53, L_54, L_55, L_56, NULL);
		V_4 = L_57;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:238>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_58 = V_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_59 = V_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_60 = V_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_61 = V_3;
		float L_62 = V_10;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_63;
		L_63 = BezierUtility_BezierPoint_m58FBF49282434261BFE28A39F3C891889F6FAF54(L_58, L_59, L_60, L_61, ((float)il2cpp_codegen_add(L_62, (0.00100000005f))), NULL);
		V_12 = L_63;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:239>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_64 = V_11;
		float L_65 = L_64.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_66 = V_11;
		float L_67 = L_66.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_68;
		memset((&L_68), 0, sizeof(L_68));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_68), L_65, L_67, (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_69 = V_4;
		float L_70 = L_69.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_71 = V_4;
		float L_72 = L_71.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_73;
		memset((&L_73), 0, sizeof(L_73));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_73), L_70, L_72, (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_74;
		L_74 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_68, L_73, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_75;
		L_75 = Vector3_Normalize_mEF8349CC39674236CFC694189AFD36E31F89AC8F_inline(L_74, NULL);
		V_13 = L_75;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:240>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_76 = V_12;
		float L_77 = L_76.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_78 = V_12;
		float L_79 = L_78.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_80;
		memset((&L_80), 0, sizeof(L_80));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_80), L_77, L_79, (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_81 = V_4;
		float L_82 = L_81.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_83 = V_4;
		float L_84 = L_83.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_85;
		memset((&L_85), 0, sizeof(L_85));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_85), L_82, L_84, (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_86;
		L_86 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_80, L_85, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_87;
		L_87 = Vector3_Normalize_mEF8349CC39674236CFC694189AFD36E31F89AC8F_inline(L_86, NULL);
		V_14 = L_87;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:241>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_88;
		L_88 = Vector3_get_up_m128AF3FDC820BF59D5DE86D973E7DE3F20C3AEBA_inline(NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_89 = V_13;
		il2cpp_codegen_runtime_class_init_inline(SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var);
		float L_90;
		L_90 = SpriteShapeObjectPlacement_Angle_m133A7031202A395E8963E07B72900C9559763B6E(L_88, L_89, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:242>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_91 = V_13;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_92 = V_14;
		float L_93;
		L_93 = SpriteShapeObjectPlacement_Angle_m133A7031202A395E8963E07B72900C9559763B6E(L_91, L_92, NULL);
		V_15 = L_93;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:243>
		float L_94 = V_15;
		V_16 = ((float)il2cpp_codegen_add(L_90, ((float)il2cpp_codegen_multiply(L_94, (0.5f)))));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:244>
		float L_95 = V_15;
		if ((!(((float)L_95) > ((float)(0.0f)))))
		{
			goto IL_01ca;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:245>
		float L_96 = V_16;
		V_16 = ((float)il2cpp_codegen_add((180.0f), L_96));
	}

IL_01ca:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:246>
		float L_97 = V_16;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_98;
		L_98 = Quaternion_Euler_m9262AB29E3E9CE94EF71051F38A28E82AEC73F90_inline((0.0f), (0.0f), L_97, NULL);
		V_17 = L_98;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:247>
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_99 = V_7;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_100;
		L_100 = Matrix4x4_get_rotation_m7E2C29FCB2AAFAE4D7B4FBD3563E9EDB53F5A8BB((&V_6), NULL);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_101 = V_17;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_102;
		L_102 = Quaternion_op_Multiply_mCB375FCCC12A2EC8F9EB824A1BFB4453B58C2012_inline(L_100, L_101, NULL);
		NullCheck(L_99);
		Transform_set_rotation_m61340DE74726CF0F9946743A727C4D444397331D(L_99, L_102, NULL);
	}

IL_01f2:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:249>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_103 = V_9;
		return L_103;
	}
}
// Method Definition Index: 65962
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 SpriteShapeObjectPlacement_PlaceObject_m7FB81E5C890FECC6A79C3A46C6BC326B2C9A4D5E (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, Spline_tD674213224F697425072FBF76AE3FD203AD2B818* ___0_spline, int32_t ___1_sp, int32_t ___2_ep, bool* ___3_run, const RuntimeMethod* method) 
{
	NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D V_0;
	memset((&V_0), 0, sizeof(V_0));
	float V_1 = 0.0f;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	float V_4 = 0.0f;
	float V_5 = 0.0f;
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:254>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_0;
		L_0 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_0);
		NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D L_1;
		L_1 = SpriteShapeController_GetShapeControlPoints_m4A0BF704DB4274546156AC4085353536541B30D5(L_0, NULL);
		V_0 = L_1;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:255>
		int32_t L_2 = ___1_sp;
		int32_t L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&V_0))->___m_Length);
		if ((((int32_t)L_2) > ((int32_t)L_3)))
		{
			goto IL_0020;
		}
	}
	{
		int32_t L_4 = ___2_ep;
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&V_0))->___m_Length);
		if ((((int32_t)L_4) <= ((int32_t)L_5)))
		{
			goto IL_002a;
		}
	}

IL_0020:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:257>
		bool* L_6 = ___3_run;
		*((int8_t*)L_6) = (int8_t)0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:258>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_7;
		L_7 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		return L_7;
	}

IL_002a:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:261>
		float L_8;
		L_8 = SpriteShapeObjectPlacement_get_ratio_m1AD37D2E67595975F88822C70707DF5EFB8B5F3B_inline(__this, NULL);
		float L_9;
		L_9 = math_clamp_mB7233FC9D6C27522014C4E6D4E056D36CE82C97E_inline(L_8, (9.99999975E-05f), (0.999899983f), NULL);
		V_1 = L_9;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:262>
		int32_t L_10 = ___2_ep;
		int32_t L_11 = ___1_sp;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract(L_10, L_11))) == ((uint32_t)1))))
		{
			goto IL_0055;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:264>
		bool* L_12 = ___3_run;
		*((int8_t*)L_12) = (int8_t)1;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:265>
		int32_t L_13 = ___1_sp;
		int32_t L_14 = ___2_ep;
		float L_15 = V_1;
		NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D L_16 = V_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_17;
		L_17 = SpriteShapeObjectPlacement_PlaceObjectInternal_m3936E149DD314A1669C8C3CA8652C68D8350361C(__this, L_13, L_14, L_15, L_16, NULL);
		return L_17;
	}

IL_0055:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:269>
		V_2 = 0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:270>
		V_3 = 0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:271>
		V_4 = (0.0f);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:272>
		V_5 = (0.0f);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:273>
		float L_18 = V_4;
		int32_t L_19 = ___1_sp;
		int32_t L_20 = ___2_ep;
		NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D L_21 = V_0;
		float L_22;
		L_22 = SpriteShapeObjectPlacement_GetDistance_m26F046CB844C933DD5EE6A5D744A857B8FB093FB(__this, L_18, L_19, L_20, (&V_2), (&V_3), (&V_5), L_21, NULL);
		float L_23 = V_1;
		V_4 = ((float)il2cpp_codegen_multiply(L_22, L_23));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:274>
		float L_24 = V_4;
		int32_t L_25 = ___1_sp;
		int32_t L_26 = ___2_ep;
		NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D L_27 = V_0;
		float L_28;
		L_28 = SpriteShapeObjectPlacement_GetDistance_m26F046CB844C933DD5EE6A5D744A857B8FB093FB(__this, L_24, L_25, L_26, (&V_2), (&V_3), (&V_5), L_27, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:275>
		int32_t L_29 = V_2;
		if ((((int32_t)L_29) < ((int32_t)0)))
		{
			goto IL_00a2;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:277>
		bool* L_30 = ___3_run;
		*((int8_t*)L_30) = (int8_t)1;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:278>
		int32_t L_31 = V_2;
		int32_t L_32 = V_3;
		float L_33 = V_5;
		NativeArray_1_t0A95B911B33C28DC2EF1F36B38506E94FCAAD50D L_34 = V_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_35;
		L_35 = SpriteShapeObjectPlacement_PlaceObjectInternal_m3936E149DD314A1669C8C3CA8652C68D8350361C(__this, L_31, L_32, L_33, L_34, NULL);
		return L_35;
	}

IL_00a2:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:281>
		bool* L_36 = ___3_run;
		*((int8_t*)L_36) = (int8_t)0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:282>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_37;
		L_37 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		return L_37;
	}
}
// Method Definition Index: 65963
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_GetSplinePointCount_mF27D6D3AAE57EF8C5A3C0FDC91A341E3BA3EE117 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	int32_t G_B3_0 = 0;
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:287>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_0;
		L_0 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_0);
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_1;
		L_1 = SpriteShapeController_get_spline_m1266CB84F33024475FA4FC6C2F35E4E3E74AD6B9_inline(L_0, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:288>
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_2 = L_1;
		NullCheck(L_2);
		int32_t L_3;
		L_3 = Spline_GetPointCount_m9A872A9A4C7CA81296EF70F93D48B8C47A5F7415(L_2, NULL);
		V_0 = L_3;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:289>
		NullCheck(L_2);
		bool L_4;
		L_4 = Spline_get_isOpenEnded_m09BD0EAEDB52B06A28C0D5718F63043791DC6861(L_2, NULL);
		if (L_4)
		{
			goto IL_001c;
		}
	}
	{
		int32_t L_5 = V_0;
		G_B3_0 = L_5;
		goto IL_001f;
	}

IL_001c:
	{
		int32_t L_6 = V_0;
		G_B3_0 = ((int32_t)il2cpp_codegen_subtract(L_6, 1));
	}

IL_001f:
	{
		V_0 = G_B3_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:290>
		int32_t L_7 = V_0;
		return L_7;
	}
}
// Method Definition Index: 65964
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool SpriteShapeObjectPlacement_Place_m67C08775427481BF5175EF5BA5455F6B837140E9 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&BezierUtility_t450F38689B5013A23432043C5922D64496EF5E60_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralB97EA8E93DF3A597AEFDD8BACBE2AD61BB9CAE61);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	bool V_1 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_2;
	memset((&V_2), 0, sizeof(V_2));
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	float V_7 = 0.0f;
	float V_8 = 0.0f;
	Spline_tD674213224F697425072FBF76AE3FD203AD2B818* V_9 = NULL;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 V_10;
	memset((&V_10), 0, sizeof(V_10));
	int32_t V_11 = 0;
	int32_t V_12 = 0;
	int32_t V_13 = 0;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_14;
	memset((&V_14), 0, sizeof(V_14));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_15;
	memset((&V_15), 0, sizeof(V_15));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_16;
	memset((&V_16), 0, sizeof(V_16));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_17;
	memset((&V_17), 0, sizeof(V_17));
	float V_18 = 0.0f;
	float V_19 = 0.0f;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_20;
	memset((&V_20), 0, sizeof(V_20));
	SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* G_B15_0 = NULL;
	SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* G_B14_0 = NULL;
	int32_t G_B16_0 = 0;
	SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* G_B16_1 = NULL;
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:295>
		int32_t L_0;
		L_0 = SpriteShapeObjectPlacement_GetSplinePointCount_mF27D6D3AAE57EF8C5A3C0FDC91A341E3BA3EE117(__this, NULL);
		V_0 = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:296>
		V_1 = (bool)0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:297>
		int32_t L_1 = __this->___m_Mode;
		if ((!(((uint32_t)L_1) == ((uint32_t)1))))
		{
			goto IL_0064;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:299>
		int32_t L_2;
		L_2 = SpriteShapeObjectPlacement_get_startPoint_m1C539FDCDDB00A0918771704D55D113549A08D12_inline(__this, NULL);
		int32_t L_3 = V_0;
		int32_t L_4;
		L_4 = math_clamp_m9EABD008C8EAD9D150062ABE724D96FA2121EE1C_inline(L_2, 0, L_3, NULL);
		V_3 = L_4;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:300>
		int32_t L_5;
		L_5 = SpriteShapeObjectPlacement_get_endPoint_m1183FA74B1AF9A9806EC708DC9AB9FC183983335_inline(__this, NULL);
		int32_t L_6 = V_0;
		int32_t L_7;
		L_7 = math_clamp_m9EABD008C8EAD9D150062ABE724D96FA2121EE1C_inline(L_5, 0, L_6, NULL);
		V_4 = L_7;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:301>
		int32_t L_8 = V_3;
		int32_t L_9 = V_4;
		if ((((int32_t)L_8) < ((int32_t)L_9)))
		{
			goto IL_004b;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:303>
		int32_t L_10 = V_0;
		SpriteShapeObjectPlacement_set_endPoint_m62B77B64D9F7332D75A19F768B1CFF1FB919C040_inline(__this, L_10, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:304>
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_11;
		L_11 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_LogWarning_m23033D7E2F0F298BE465B7F3A63CDF40A4EB70EB(_stringLiteralB97EA8E93DF3A597AEFDD8BACBE2AD61BB9CAE61, L_11, NULL);
	}

IL_004b:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:306>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_12;
		L_12 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_12);
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_13;
		L_13 = SpriteShapeController_get_spline_m1266CB84F33024475FA4FC6C2F35E4E3E74AD6B9_inline(L_12, NULL);
		int32_t L_14 = V_3;
		int32_t L_15 = V_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_16;
		L_16 = SpriteShapeObjectPlacement_PlaceObject_m7FB81E5C890FECC6A79C3A46C6BC326B2C9A4D5E(__this, L_13, L_14, L_15, (&V_1), NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:307>
		bool L_17 = V_1;
		return L_17;
	}

IL_0064:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:310>
		il2cpp_codegen_runtime_class_init_inline(SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var);
		float L_18 = ((SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_StaticFields*)il2cpp_codegen_static_fields_for(SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var))->___kMaxDistance;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:311>
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_19;
		L_19 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		NullCheck(L_19);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_20;
		L_20 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_19, NULL);
		V_2 = L_20;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:312>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_21;
		L_21 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:314>
		V_5 = 0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:314>
		V_6 = 0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:315>
		V_7 = (100.0f);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:315>
		float L_22 = ((SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_StaticFields*)il2cpp_codegen_static_fields_for(SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var))->___kMaxDistance;
		V_8 = L_22;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:316>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_23;
		L_23 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_23);
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_24;
		L_24 = SpriteShapeController_get_spline_m1266CB84F33024475FA4FC6C2F35E4E3E74AD6B9_inline(L_23, NULL);
		V_9 = L_24;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:317>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_25;
		L_25 = SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline(__this, NULL);
		NullCheck(L_25);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_26;
		L_26 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(L_25, NULL);
		NullCheck(L_26);
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 L_27;
		L_27 = Transform_get_localToWorldMatrix_m5D35188766856338DD21DE756F42277C21719E6D(L_26, NULL);
		V_10 = L_27;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:318>
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_28 = V_9;
		NullCheck(L_28);
		int32_t L_29;
		L_29 = Spline_GetPointCount_m9A872A9A4C7CA81296EF70F93D48B8C47A5F7415(L_28, NULL);
		V_11 = L_29;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:320>
		V_12 = 0;
		goto IL_0158;
	}

IL_00c0:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:322>
		int32_t L_30 = V_12;
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_31 = V_9;
		NullCheck(L_31);
		int32_t L_32;
		L_32 = Spline_GetPointCount_m9A872A9A4C7CA81296EF70F93D48B8C47A5F7415(L_31, NULL);
		V_13 = ((int32_t)(((int32_t)il2cpp_codegen_add(L_30, 1))%L_32));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:323>
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_33 = V_9;
		int32_t L_34 = V_12;
		NullCheck(L_33);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_35;
		L_35 = Spline_GetPosition_m68F7EECA5140A4D6C0FAA8AB9F8DED9BF214CF9C(L_33, L_34, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_36;
		L_36 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814((&V_10), L_35, NULL);
		V_14 = L_36;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:324>
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_37 = V_9;
		int32_t L_38 = V_13;
		NullCheck(L_37);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_39;
		L_39 = Spline_GetPosition_m68F7EECA5140A4D6C0FAA8AB9F8DED9BF214CF9C(L_37, L_38, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_40;
		L_40 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814((&V_10), L_39, NULL);
		V_15 = L_40;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:325>
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_41 = V_9;
		int32_t L_42 = V_12;
		NullCheck(L_41);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_43;
		L_43 = Spline_GetRightTangent_m6008A3450C5E0D85D57FA8A1453670CBC5B280EF(L_41, L_42, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_44 = V_14;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_45;
		L_45 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_43, L_44, NULL);
		V_16 = L_45;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:326>
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_46 = V_9;
		int32_t L_47 = V_13;
		NullCheck(L_46);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_48;
		L_48 = Spline_GetLeftTangent_m722F61220067D72DD8CDD817E9174F331778A398(L_46, L_47, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_49 = V_15;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_50;
		L_50 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_48, L_49, NULL);
		V_17 = L_50;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:329>
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:330>
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:331>
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:332>
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:333>
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:334>
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:335>
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:336>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_51 = V_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_52 = V_14;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_53 = V_15;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_54 = V_16;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_55 = V_17;
		il2cpp_codegen_runtime_class_init_inline(BezierUtility_t450F38689B5013A23432043C5922D64496EF5E60_il2cpp_TypeInfo_var);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_56;
		L_56 = BezierUtility_ClosestPointOnCurve_m91458888AC7667493117C7BE8E339A404533656C(L_51, L_52, L_53, L_54, L_55, (9.99999975E-05f), (&V_18), NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:337>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_57 = V_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_58;
		L_58 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_56, L_57, NULL);
		V_20 = L_58;
		float L_59;
		L_59 = Vector3_get_magnitude_mF0D6017E90B345F1F52D1CC564C640F1A847AF2D_inline((&V_20), NULL);
		V_19 = L_59;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:338>
		float L_60 = V_19;
		float L_61 = V_8;
		if ((!(((float)L_60) < ((float)L_61))))
		{
			goto IL_0152;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:340>
		int32_t L_62 = V_12;
		V_5 = L_62;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:341>
		int32_t L_63 = V_13;
		V_6 = L_63;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:342>
		float L_64 = V_18;
		V_7 = L_64;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:343>
		float L_65 = V_19;
		V_8 = L_65;
	}

IL_0152:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:320>
		int32_t L_66 = V_12;
		V_12 = ((int32_t)il2cpp_codegen_add(L_66, 1));
	}

IL_0158:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:320>
		int32_t L_67 = V_12;
		int32_t L_68 = V_0;
		if ((((int32_t)L_67) < ((int32_t)L_68)))
		{
			goto IL_00c0;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:348>
		int32_t L_69 = V_5;
		if ((((int32_t)L_69) < ((int32_t)0)))
		{
			goto IL_01af;
		}
	}
	{
		int32_t L_70 = V_5;
		int32_t L_71 = V_11;
		if ((((int32_t)L_70) >= ((int32_t)L_71)))
		{
			goto IL_01af;
		}
	}
	{
		int32_t L_72 = V_6;
		if ((((int32_t)L_72) < ((int32_t)0)))
		{
			goto IL_01af;
		}
	}
	{
		int32_t L_73 = V_6;
		int32_t L_74 = V_11;
		if ((((int32_t)L_73) >= ((int32_t)L_74)))
		{
			goto IL_01af;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:350>
		int32_t L_75 = V_5;
		SpriteShapeObjectPlacement_set_startPoint_m2C880BECFF67C3478402FF2A88C8F5F5E2E60CA6_inline(__this, L_75, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:351>
		int32_t L_76 = V_6;
		if (!L_76)
		{
			G_B15_0 = __this;
			goto IL_0187;
		}
		G_B14_0 = __this;
	}
	{
		int32_t L_77 = V_6;
		G_B16_0 = L_77;
		G_B16_1 = G_B14_0;
		goto IL_018b;
	}

IL_0187:
	{
		int32_t L_78 = V_5;
		G_B16_0 = ((int32_t)il2cpp_codegen_add(L_78, 1));
		G_B16_1 = G_B15_0;
	}

IL_018b:
	{
		NullCheck(G_B16_1);
		SpriteShapeObjectPlacement_set_endPoint_m62B77B64D9F7332D75A19F768B1CFF1FB919C040_inline(G_B16_1, G_B16_0, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:352>
		float L_79 = V_7;
		SpriteShapeObjectPlacement_set_ratio_mED658B93A3A246178CCB30DEC877EA54DA1842EC_inline(__this, L_79, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:353>
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_80 = V_9;
		int32_t L_81;
		L_81 = SpriteShapeObjectPlacement_get_startPoint_m1C539FDCDDB00A0918771704D55D113549A08D12_inline(__this, NULL);
		int32_t L_82;
		L_82 = SpriteShapeObjectPlacement_get_endPoint_m1183FA74B1AF9A9806EC708DC9AB9FC183983335_inline(__this, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_83;
		L_83 = SpriteShapeObjectPlacement_PlaceObject_m7FB81E5C890FECC6A79C3A46C6BC326B2C9A4D5E(__this, L_80, L_81, L_82, (&V_1), NULL);
		V_2 = L_83;
	}

IL_01af:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:356>
		bool L_84 = V_1;
		return L_84;
	}
}
// Method Definition Index: 65965
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_Start_m31DF5A864CF990FAF9C0C1F1EAA899872848B0D8 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:361>
		bool L_0;
		L_0 = SpriteShapeObjectPlacement_PlaceObjectOnHashChange_m71263E4A1E32BA74D19300AC80B4D9A544441692(__this, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:362>
		return;
	}
}
// Method Definition Index: 65966
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_Update_m6EE91B72EC1D2A270BE170A5B58C88EA3D0F90A6 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:366>
		bool L_0;
		L_0 = SpriteShapeObjectPlacement_PlaceObjectOnHashChange_m71263E4A1E32BA74D19300AC80B4D9A544441692(__this, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:367>
		return;
	}
}
// Method Definition Index: 65967
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement__ctor_mAF1BA203CB3BF07C913E949F60542FA53B607C71 (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:35>
		__this->___m_SetNormal = (bool)1;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:46>
		__this->___m_EndPoint = 1;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:49>
		__this->___m_Ratio = (0.5f);
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		return;
	}
}
// Method Definition Index: 65968
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement__cctor_m78FEDC6133B00B5AD3D7E02315D054DBC519D209 (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:53>
		((SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_StaticFields*)il2cpp_codegen_static_fields_for(SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var))->___kMaxDistance = (10000.0f);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:54>
		((SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_StaticFields*)il2cpp_codegen_static_fields_for(SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB_il2cpp_TypeInfo_var))->___kMaxIteration = ((int32_t)128);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Method Definition Index: 65969
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U24BurstDirectCallInitializer_Initialize_m9CB01D973E72EFDACCBA8B435C93D60D5369B5FD (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	BurstCompilerOptions_t5F93118F305E1B0C950C6F9AF8BCA74033DA01C9* V_0 = NULL;
	{
		il2cpp_codegen_runtime_class_init_inline(BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_il2cpp_TypeInfo_var);
		BurstCompilerOptions_t5F93118F305E1B0C950C6F9AF8BCA74033DA01C9* L_0 = ((BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_StaticFields*)il2cpp_codegen_static_fields_for(BurstCompiler_t2715484E1FF256726FC4D4D8E17C35A4C8DFA2B8_il2cpp_TypeInfo_var))->___Options;
		V_0 = L_0;
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Method Definition Index: 37571
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x = L_0;
		float L_1 = ___1_y;
		__this->___y = L_1;
		return;
	}
}
// Method Definition Index: 65927
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_NO_INLINE IL2CPP_METHOD_ATTR void SpriteShapeGenerator_UTessellatorU24BurstManaged_m6F4F57B7363784CE1724AE26829C356319E88118_inline (SpriteShapeSegment_tB32CE039E823A27997165CD087F6DE1906C4C8D5* ___0_geom, int32_t ___1_maxCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_tessPoints, int32_t ___3_tessPointCount, uint16_t* ___4_indices, int32_t* ___5_iCount, uint8_t* ___6_vertices, int32_t ___7_stride, int32_t* ___8_vCount, int32_t ___9_label, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_t2F8BE4233858E78501EF0B4D650CECD9A6D5D9F4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E V_1;
	memset((&V_1), 0, sizeof(V_1));
	float V_2 = 0.0f;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_3;
	memset((&V_3), 0, sizeof(V_3));
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E V_4;
	memset((&V_4), 0, sizeof(V_4));
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_5;
	memset((&V_5), 0, sizeof(V_5));
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_6;
	memset((&V_6), 0, sizeof(V_6));
	int32_t V_7 = 0;
	int32_t V_8 = 0;
	int32_t V_9 = 0;
	int32_t V_10 = 0;
	int32_t V_11 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_12;
	memset((&V_12), 0, sizeof(V_12));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* V_13 = NULL;
	int32_t G_B9_0 = 0;
	int32_t G_B12_0 = 0;
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1210>
		int32_t L_0 = ___3_tessPointCount;
		int32_t L_1 = ___9_label;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_0), ((int32_t)il2cpp_codegen_subtract(L_0, 1)), L_1, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1211>
		int32_t L_2 = ___3_tessPointCount;
		int32_t L_3 = ___9_label;
		NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A((&V_1), ((int32_t)il2cpp_codegen_subtract(L_2, 1)), L_3, 1, NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1212>
		V_2 = (1.0f);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1213>
		V_10 = 0;
		goto IL_004b;
	}

IL_0025:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1214>
		int32_t L_4 = V_10;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_5 = ___2_tessPoints;
		int32_t L_6 = V_10;
		uint32_t L_7 = sizeof(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8 = (*(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)((float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)il2cpp_codegen_add((intptr_t)L_5, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)L_6), (int32_t)L_7)))));
		float L_9 = V_2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10;
		L_10 = float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline(L_8, L_9, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&V_1))->___m_Buffer, L_4, (L_10));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1213>
		int32_t L_11 = V_10;
		V_10 = ((int32_t)il2cpp_codegen_add(L_11, 1));
	}

IL_004b:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1213>
		int32_t L_12 = V_10;
		int32_t L_13;
		L_13 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&V_1))->___m_Length);
		if ((((int32_t)L_12) < ((int32_t)L_13)))
		{
			goto IL_0025;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1216>
		V_11 = 0;
		goto IL_008b;
	}

IL_005b:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1218>
		int32_t L_14 = V_11;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_15;
		L_15 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&V_0))->___m_Buffer, L_14);
		V_12 = L_15;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1219>
		int32_t L_16 = V_11;
		(&V_12)->___x = L_16;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1220>
		int32_t L_17 = V_11;
		(&V_12)->___y = ((int32_t)il2cpp_codegen_add(L_17, 1));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1221>
		int32_t L_18 = V_11;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_19 = V_12;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&V_0))->___m_Buffer, L_18, (L_19));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1216>
		int32_t L_20 = V_11;
		V_11 = ((int32_t)il2cpp_codegen_add(L_20, 1));
	}

IL_008b:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1216>
		int32_t L_21 = V_11;
		int32_t L_22 = ___3_tessPointCount;
		if ((((int32_t)L_21) < ((int32_t)((int32_t)il2cpp_codegen_subtract(L_22, 2)))))
		{
			goto IL_005b;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1223>
		int32_t L_23 = ___3_tessPointCount;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_24;
		L_24 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&V_0))->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_23, 2)));
		V_3 = L_24;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1224>
		int32_t L_25 = ___3_tessPointCount;
		(&V_3)->___x = ((int32_t)il2cpp_codegen_subtract(L_25, 2));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1225>
		(&V_3)->___y = 0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1226>
		int32_t L_26 = ___3_tessPointCount;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_27 = V_3;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&V_0))->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_26, 2)), (L_27));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1228>
		int32_t L_28 = ___3_tessPointCount;
		int32_t L_29 = ___9_label;
		NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A((&V_4), ((int32_t)il2cpp_codegen_multiply(L_28, 4)), L_29, 1, NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1229>
		int32_t L_30 = ___3_tessPointCount;
		int32_t L_31 = ___9_label;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_5), ((int32_t)il2cpp_codegen_multiply(L_30, 4)), L_31, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1230>
		int32_t L_32 = ___3_tessPointCount;
		int32_t L_33 = ___9_label;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_6), ((int32_t)il2cpp_codegen_multiply(L_32, 4)), L_33, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1231>
		int32_t L_34 = ___9_label;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_t2F8BE4233858E78501EF0B4D650CECD9A6D5D9F4_il2cpp_TypeInfo_var);
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_35;
		L_35 = ModuleHandle_Tessellate_mDCFCA96AD66F268C584B76699ECF5632D0C0E352(L_34, (&V_1), (&V_0), (&V_4), (&V_7), (&V_5), (&V_8), (&V_6), (&V_9), (bool)0, NULL);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1232>
		int32_t L_36 = V_7;
		int32_t L_37 = ___1_maxCount;
		if ((((int32_t)L_36) < ((int32_t)L_37)))
		{
			goto IL_0102;
		}
	}
	{
		int32_t L_38 = ___1_maxCount;
		G_B9_0 = L_38;
		goto IL_0104;
	}

IL_0102:
	{
		int32_t L_39 = V_7;
		G_B9_0 = L_39;
	}

IL_0104:
	{
		V_7 = G_B9_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1233>
		int32_t L_40 = V_8;
		int32_t L_41 = ___1_maxCount;
		if ((((int32_t)L_40) < ((int32_t)L_41)))
		{
			goto IL_010e;
		}
	}
	{
		int32_t L_42 = ___1_maxCount;
		G_B12_0 = L_42;
		goto IL_0110;
	}

IL_010e:
	{
		int32_t L_43 = V_8;
		G_B12_0 = L_43;
	}

IL_0110:
	{
		V_8 = G_B12_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1235>
		int32_t L_44 = V_8;
		if ((((int32_t)L_44) <= ((int32_t)0)))
		{
			goto IL_0196;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1237>
		int32_t* L_45 = ___8_vCount;
		*((int32_t*)L_45) = (int32_t)0;
		goto IL_0165;
	}

IL_011d:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1239>
		uint8_t* L_46 = ___6_vertices;
		V_13 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_46;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1240>
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_47 = V_13;
		int32_t* L_48 = ___8_vCount;
		int32_t L_49 = *((int32_t*)L_48);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_50;
		L_50 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&V_4))->___m_Buffer, L_49);
		float L_51 = L_50.___x;
		int32_t* L_52 = ___8_vCount;
		int32_t L_53 = *((int32_t*)L_52);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_54;
		L_54 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&V_4))->___m_Buffer, L_53);
		float L_55 = L_54.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_56;
		memset((&L_56), 0, sizeof(L_56));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_56), L_51, L_55, (0.0f), NULL);
		float L_57 = V_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_58;
		L_58 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_56, L_57, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_47 = L_58;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1241>
		uint8_t* L_59 = ___6_vertices;
		int32_t L_60 = ___7_stride;
		___6_vertices = ((uint8_t*)il2cpp_codegen_add((intptr_t)L_59, L_60));
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1237>
		int32_t* L_61 = ___8_vCount;
		int32_t* L_62 = ___8_vCount;
		int32_t L_63 = *((int32_t*)L_62);
		*((int32_t*)L_61) = (int32_t)((int32_t)il2cpp_codegen_add(L_63, 1));
	}

IL_0165:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1237>
		int32_t* L_64 = ___8_vCount;
		int32_t L_65 = *((int32_t*)L_64);
		int32_t L_66 = V_7;
		if ((((int32_t)L_65) < ((int32_t)L_66)))
		{
			goto IL_011d;
		}
	}
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1243>
		int32_t* L_67 = ___5_iCount;
		*((int32_t*)L_67) = (int32_t)0;
		goto IL_018f;
	}

IL_0172:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1244>
		uint16_t* L_68 = ___4_indices;
		int32_t* L_69 = ___5_iCount;
		int32_t L_70 = *((int32_t*)L_69);
		int32_t* L_71 = ___5_iCount;
		int32_t L_72 = *((int32_t*)L_71);
		int32_t L_73;
		L_73 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&V_5))->___m_Buffer, L_72);
		*((int16_t*)((uint16_t*)il2cpp_codegen_add((intptr_t)L_68, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)L_70), 2))))) = (int16_t)((int32_t)(uint16_t)L_73);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1243>
		int32_t* L_74 = ___5_iCount;
		int32_t* L_75 = ___5_iCount;
		int32_t L_76 = *((int32_t*)L_75);
		*((int32_t*)L_74) = (int32_t)((int32_t)il2cpp_codegen_add(L_76, 1));
	}

IL_018f:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1243>
		int32_t* L_77 = ___5_iCount;
		int32_t L_78 = *((int32_t*)L_77);
		int32_t L_79 = V_8;
		if ((((int32_t)L_78) < ((int32_t)L_79)))
		{
			goto IL_0172;
		}
	}

IL_0196:
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1247>
		NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F((&V_4), NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1248>
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_5), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1249>
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_6), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1250>
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_0), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1251>
		NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F((&V_1), NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeGenerator.cs:1252>
		return;
	}
}
// Method Definition Index: 65952
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* SpriteShapeObjectPlacement_get_spriteShapeController_mA90BED3A705B97FDC4B368365F65922EB268BB2E_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:88>
		SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* L_0 = __this->___m_SpriteShapeController;
		return L_0;
	}
}
// Method Definition Index: 65740
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeController_get_splineHashCode_m5FD24A66B300EA0F8E1A1B0E5100ED3D0AA8FB98_inline (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeController.cs:130>
		int32_t L_0 = __this->___m_ActiveSplineHash;
		return L_0;
	}
}
// Method Definition Index: 65751
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeController_get_spriteShapeHashCode_mF2D6ABCAF590DFC5A0461E61A8B78356FD2FB520_inline (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeController.cs:202>
		int32_t L_0 = __this->___m_ActiveSpriteShapeHash;
		return L_0;
	}
}
// Method Definition Index: 65946
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool SpriteShapeObjectPlacement_get_setNormal_mDF4F4E07D5CD4B8A7D5A3B1A280BB21FBD8A0567_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:61>
		bool L_0 = __this->___m_SetNormal;
		return L_0;
	}
}
// Method Definition Index: 65954
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_get_startPoint_m1C539FDCDDB00A0918771704D55D113549A08D12_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:97>
		int32_t L_0 = __this->___m_StartPoint;
		return L_0;
	}
}
// Method Definition Index: 65956
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeObjectPlacement_get_endPoint_m1183FA74B1AF9A9806EC708DC9AB9FC183983335_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:106>
		int32_t L_0 = __this->___m_EndPoint;
		return L_0;
	}
}
// Method Definition Index: 37450
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Vector3_GetHashCode_mB08429DC931A85BD29CE11B9ABC77DE7E0E46327_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		float* L_0 = (float*)(&__this->___x);
		int32_t L_1;
		L_1 = Single_GetHashCode_mC3F1E099D1CF165C2D71FBCC5EF6A6792F9021D2(L_0, NULL);
		float* L_2 = (float*)(&__this->___y);
		int32_t L_3;
		L_3 = Single_GetHashCode_mC3F1E099D1CF165C2D71FBCC5EF6A6792F9021D2(L_2, NULL);
		float* L_4 = (float*)(&__this->___z);
		int32_t L_5;
		L_5 = Single_GetHashCode_mC3F1E099D1CF165C2D71FBCC5EF6A6792F9021D2(L_4, NULL);
		V_0 = ((int32_t)(((int32_t)(L_1^((int32_t)(L_3<<2))))^((int32_t)(L_5>>2))));
		goto IL_002b;
	}

IL_002b:
	{
		int32_t L_6 = V_0;
		return L_6;
	}
}
// Method Definition Index: 37507
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Quaternion_GetHashCode_m5F55C34C98E437376595E722BE4EB8A70434F049_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974* __this, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		float* L_0 = (float*)(&__this->___x);
		int32_t L_1;
		L_1 = Single_GetHashCode_mC3F1E099D1CF165C2D71FBCC5EF6A6792F9021D2(L_0, NULL);
		float* L_2 = (float*)(&__this->___y);
		int32_t L_3;
		L_3 = Single_GetHashCode_mC3F1E099D1CF165C2D71FBCC5EF6A6792F9021D2(L_2, NULL);
		float* L_4 = (float*)(&__this->___z);
		int32_t L_5;
		L_5 = Single_GetHashCode_mC3F1E099D1CF165C2D71FBCC5EF6A6792F9021D2(L_4, NULL);
		float* L_6 = (float*)(&__this->___w);
		int32_t L_7;
		L_7 = Single_GetHashCode_mC3F1E099D1CF165C2D71FBCC5EF6A6792F9021D2(L_6, NULL);
		V_0 = ((int32_t)(((int32_t)(((int32_t)(L_1^((int32_t)(L_3<<2))))^((int32_t)(L_5>>2))))^((int32_t)(L_7>>1))));
		goto IL_0039;
	}

IL_0039:
	{
		int32_t L_8 = V_0;
		return L_8;
	}
}
// Method Definition Index: 1190
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Double_GetHashCode_m3761FC05AD24D97A68FA1E8412A9454DF3880E32_inline (double* __this, const RuntimeMethod* method) 
{
	int64_t V_0 = 0;
	{
		double L_0 = *((double*)__this);
		int64_t L_1;
		L_1 = BitConverter_DoubleToInt64Bits_m4F42741818550F9956B5FBAF88C051F4DE5B0AE6_inline(L_0, NULL);
		V_0 = L_1;
		int64_t L_2 = V_0;
		if ((((int64_t)((int64_t)(((int64_t)il2cpp_codegen_subtract(L_2, ((int64_t)1)))&((int64_t)(std::numeric_limits<int64_t>::max)())))) < ((int64_t)((int64_t)9218868437227405312LL))))
		{
			goto IL_002d;
		}
	}
	{
		int64_t L_3 = V_0;
		V_0 = ((int64_t)(L_3&((int64_t)9218868437227405312LL)));
	}

IL_002d:
	{
		int64_t L_4 = V_0;
		int64_t L_5 = V_0;
		return ((int32_t)(((int32_t)L_4)^((int32_t)((int64_t)(L_5>>((int32_t)32))))));
	}
}
// Method Definition Index: 65950
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float SpriteShapeObjectPlacement_get_ratio_m1AD37D2E67595975F88822C70707DF5EFB8B5F3B_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:79>
		float L_0 = __this->___m_Ratio;
		return L_0;
	}
}
// Method Definition Index: 37456
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Vector3_Dot_mBB86BB940AA0A32FA7D3C02AC42E5BC7095A5D52_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_lhs, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_rhs, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___1_rhs;
		float L_3 = L_2.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_lhs;
		float L_5 = L_4.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___1_rhs;
		float L_7 = L_6.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_lhs;
		float L_9 = L_8.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___1_rhs;
		float L_11 = L_10.___z;
		V_0 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1, L_3)), ((float)il2cpp_codegen_multiply(L_5, L_7)))), ((float)il2cpp_codegen_multiply(L_9, L_11))));
		goto IL_002d;
	}

IL_002d:
	{
		float L_12 = V_0;
		return L_12;
	}
}
// Method Definition Index: 65760
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SpriteShapeController_get_splineDetail_mB03C316DE81143E38A30C15C339D36DAD7C56E33_inline (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeController.cs:236>
		int32_t L_0 = __this->___m_SplineDetail;
		return L_0;
	}
}
// Method Definition Index: 37475
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___1_b;
		float L_3 = L_2.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_a;
		float L_5 = L_4.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___1_b;
		float L_7 = L_6.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_a;
		float L_9 = L_8.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___1_b;
		float L_11 = L_10.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_add(L_1, L_3)), ((float)il2cpp_codegen_add(L_5, L_7)), ((float)il2cpp_codegen_add(L_9, L_11)), NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
// Method Definition Index: 41703
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_distance_m516495927BCF37E20FFA3E99C821062D329DFFF8_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_x, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_y, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:3721>
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_0 = ___1_y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_1 = ___0_x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_2;
		L_2 = float3_op_Subtraction_mB6036E9849D95650D6E73DA0D179CD7B61E696F2_inline(L_0, L_1, NULL);
		float L_3;
		L_3 = math_length_m6A2B63D7A3B84261C2F7FCAA2CB382288A57D257_inline(L_2, NULL);
		return L_3;
	}
}
// Method Definition Index: 37447
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x = L_0;
		float L_1 = ___1_y;
		__this->___y = L_1;
		float L_2 = ___2_z;
		__this->___z = L_2;
		return;
	}
}
// Method Definition Index: 41400
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_clamp_mB7233FC9D6C27522014C4E6D4E056D36CE82C97E_inline (float ___0_valueToClamp, float ___1_lowerBound, float ___2_upperBound, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:1699>
		float L_0 = ___1_lowerBound;
		float L_1 = ___2_upperBound;
		float L_2 = ___0_valueToClamp;
		float L_3;
		L_3 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_1, L_2, NULL);
		float L_4;
		L_4 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_0, L_3, NULL);
		return L_4;
	}
}
// Method Definition Index: 37476
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___1_b;
		float L_3 = L_2.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_a;
		float L_5 = L_4.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___1_b;
		float L_7 = L_6.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_a;
		float L_9 = L_8.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___1_b;
		float L_11 = L_10.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)), ((float)il2cpp_codegen_subtract(L_9, L_11)), NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
// Method Definition Index: 37453
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_Normalize_mEF8349CC39674236CFC694189AFD36E31F89AC8F_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_value, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	bool V_1 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_2;
	memset((&V_2), 0, sizeof(V_2));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_value;
		float L_1;
		L_1 = Vector3_Magnitude_m21652D951393A3D7CE92CE40049A0E7F76544D1B_inline(L_0, NULL);
		V_0 = L_1;
		float L_2 = V_0;
		V_1 = (bool)((((float)L_2) > ((float)(9.99999975E-06f)))? 1 : 0);
		bool L_3 = V_1;
		if (!L_3)
		{
			goto IL_001e;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_value;
		float L_5 = V_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6;
		L_6 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_4, L_5, NULL);
		V_2 = L_6;
		goto IL_0026;
	}

IL_001e:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_7;
		L_7 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_2 = L_7;
		goto IL_0026;
	}

IL_0026:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = V_2;
		return L_8;
	}
}
// Method Definition Index: 37471
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_up_m128AF3FDC820BF59D5DE86D973E7DE3F20C3AEBA_inline (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ((Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields*)il2cpp_codegen_static_fields_for(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var))->___upVector;
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1 = V_0;
		return L_1;
	}
}
// Method Definition Index: 37504
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_Euler_m9262AB29E3E9CE94EF71051F38A28E82AEC73F90_inline (float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) 
{
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		float L_0 = ___0_x;
		float L_1 = ___1_y;
		float L_2 = ___2_z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3;
		memset((&L_3), 0, sizeof(L_3));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_3), L_0, L_1, L_2, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4;
		L_4 = Vector3_op_Multiply_m87BA7C578F96C8E49BB07088DAAC4649F83B0353_inline(L_3, (0.0174532924f), NULL);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_5;
		L_5 = Quaternion_Internal_FromEulerRad_m66D4475341F53949471E6870FB5C5E4A5E9BA93E(L_4, NULL);
		V_0 = L_5;
		goto IL_001b;
	}

IL_001b:
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_6 = V_0;
		return L_6;
	}
}
// Method Definition Index: 37496
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_op_Multiply_mCB375FCCC12A2EC8F9EB824A1BFB4453B58C2012_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___0_lhs, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___1_rhs, const RuntimeMethod* method) 
{
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_0 = ___0_lhs;
		float L_1 = L_0.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_2 = ___1_rhs;
		float L_3 = L_2.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_4 = ___0_lhs;
		float L_5 = L_4.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_6 = ___1_rhs;
		float L_7 = L_6.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_8 = ___0_lhs;
		float L_9 = L_8.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_10 = ___1_rhs;
		float L_11 = L_10.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_12 = ___0_lhs;
		float L_13 = L_12.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_14 = ___1_rhs;
		float L_15 = L_14.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_16 = ___0_lhs;
		float L_17 = L_16.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_18 = ___1_rhs;
		float L_19 = L_18.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_20 = ___0_lhs;
		float L_21 = L_20.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_22 = ___1_rhs;
		float L_23 = L_22.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_24 = ___0_lhs;
		float L_25 = L_24.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_26 = ___1_rhs;
		float L_27 = L_26.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_28 = ___0_lhs;
		float L_29 = L_28.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_30 = ___1_rhs;
		float L_31 = L_30.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_32 = ___0_lhs;
		float L_33 = L_32.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_34 = ___1_rhs;
		float L_35 = L_34.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_36 = ___0_lhs;
		float L_37 = L_36.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_38 = ___1_rhs;
		float L_39 = L_38.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_40 = ___0_lhs;
		float L_41 = L_40.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_42 = ___1_rhs;
		float L_43 = L_42.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_44 = ___0_lhs;
		float L_45 = L_44.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_46 = ___1_rhs;
		float L_47 = L_46.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_48 = ___0_lhs;
		float L_49 = L_48.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_50 = ___1_rhs;
		float L_51 = L_50.___w;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_52 = ___0_lhs;
		float L_53 = L_52.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_54 = ___1_rhs;
		float L_55 = L_54.___x;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_56 = ___0_lhs;
		float L_57 = L_56.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_58 = ___1_rhs;
		float L_59 = L_58.___y;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_60 = ___0_lhs;
		float L_61 = L_60.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_62 = ___1_rhs;
		float L_63 = L_62.___z;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_64;
		memset((&L_64), 0, sizeof(L_64));
		Quaternion__ctor_m868FD60AA65DD5A8AC0C5DEB0608381A8D85FCD8_inline((&L_64), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1, L_3)), ((float)il2cpp_codegen_multiply(L_5, L_7)))), ((float)il2cpp_codegen_multiply(L_9, L_11)))), ((float)il2cpp_codegen_multiply(L_13, L_15)))), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_17, L_19)), ((float)il2cpp_codegen_multiply(L_21, L_23)))), ((float)il2cpp_codegen_multiply(L_25, L_27)))), ((float)il2cpp_codegen_multiply(L_29, L_31)))), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_33, L_35)), ((float)il2cpp_codegen_multiply(L_37, L_39)))), ((float)il2cpp_codegen_multiply(L_41, L_43)))), ((float)il2cpp_codegen_multiply(L_45, L_47)))), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_multiply(L_49, L_51)), ((float)il2cpp_codegen_multiply(L_53, L_55)))), ((float)il2cpp_codegen_multiply(L_57, L_59)))), ((float)il2cpp_codegen_multiply(L_61, L_63)))), NULL);
		V_0 = L_64;
		goto IL_00e5;
	}

IL_00e5:
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_65 = V_0;
		return L_65;
	}
}
// Method Definition Index: 37467
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ((Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields*)il2cpp_codegen_static_fields_for(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var))->___zeroVector;
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1 = V_0;
		return L_1;
	}
}
// Method Definition Index: 65773
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Spline_tD674213224F697425072FBF76AE3FD203AD2B818* SpriteShapeController_get_spline_m1266CB84F33024475FA4FC6C2F35E4E3E74AD6B9_inline (SpriteShapeController_t38EBBE01E82A48B3533CADFCDB5B23BEA68EDC17* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeController.cs:289>
		Spline_tD674213224F697425072FBF76AE3FD203AD2B818* L_0 = __this->___m_Spline;
		return L_0;
	}
}
// Method Definition Index: 41390
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_clamp_m9EABD008C8EAD9D150062ABE724D96FA2121EE1C_inline (int32_t ___0_valueToClamp, int32_t ___1_lowerBound, int32_t ___2_upperBound, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:1616>
		int32_t L_0 = ___1_lowerBound;
		int32_t L_1 = ___2_upperBound;
		int32_t L_2 = ___0_valueToClamp;
		int32_t L_3;
		L_3 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_1, L_2, NULL);
		int32_t L_4;
		L_4 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_0, L_3, NULL);
		return L_4;
	}
}
// Method Definition Index: 65957
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_endPoint_m62B77B64D9F7332D75A19F768B1CFF1FB919C040_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:107>
		int32_t L_0 = ___0_value;
		__this->___m_EndPoint = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:107>
		return;
	}
}
// Method Definition Index: 37462
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Vector3_get_magnitude_mF0D6017E90B345F1F52D1CC564C640F1A847AF2D_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	{
		float L_0 = __this->___x;
		float L_1 = __this->___x;
		float L_2 = __this->___y;
		float L_3 = __this->___y;
		float L_4 = __this->___z;
		float L_5 = __this->___z;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		double L_6;
		L_6 = sqrt(((double)((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_0, L_1)), ((float)il2cpp_codegen_multiply(L_2, L_3)))), ((float)il2cpp_codegen_multiply(L_4, L_5))))));
		V_0 = ((float)L_6);
		goto IL_0034;
	}

IL_0034:
	{
		float L_7 = V_0;
		return L_7;
	}
}
// Method Definition Index: 65955
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_startPoint_m2C880BECFF67C3478402FF2A88C8F5F5E2E60CA6_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, int32_t ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:98>
		int32_t L_0 = ___0_value;
		__this->___m_StartPoint = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:98>
		return;
	}
}
// Method Definition Index: 65951
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void SpriteShapeObjectPlacement_set_ratio_mED658B93A3A246178CCB30DEC877EA54DA1842EC_inline (SpriteShapeObjectPlacement_t353FCF6189C80FC27BF8A579CF73D5E32C7776FB* __this, float ___0_value, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:80>
		float L_0 = ___0_value;
		__this->___m_Ratio = L_0;
		//<source_info:./Library/PackageCache/com.unity.2d.spriteshape@1d246726c231/Runtime/SpriteShapeObjectPlacement.cs:80>
		return;
	}
}
// Method Definition Index: 55469
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR intptr_t FunctionPointer_1_get_Value_m71D7FF781C694A7C4EE28362DFC78D8DDFE9A105_gshared_inline (FunctionPointer_1_tE1DC1EC606FB2242FB50357BBA39BB4AEDECFCB2* __this, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.burst@f7a407abf4d5/Runtime/FunctionPointer.cs:46>
		intptr_t L_0 = __this->____ptr;
		return L_0;
	}
}
// Method Definition Index: 44698
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float ___1_rhs, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float2.gen.cs:230>
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		float L_2 = ___1_rhs;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_3 = ___0_lhs;
		float L_4 = L_3.___y;
		float L_5 = ___1_rhs;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6;
		memset((&L_6), 0, sizeof(L_6));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_6), ((float)il2cpp_codegen_multiply(L_1, L_2)), ((float)il2cpp_codegen_multiply(L_4, L_5)), NULL);
		return L_6;
	}
}
// Method Definition Index: 37480
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x;
		float L_2 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3 = ___0_a;
		float L_4 = L_3.___y;
		float L_5 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___0_a;
		float L_7 = L_6.___z;
		float L_8 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_9;
		memset((&L_9), 0, sizeof(L_9));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_9), ((float)(L_1/L_2)), ((float)(L_4/L_5)), ((float)(L_7/L_8)), NULL);
		V_0 = L_9;
		goto IL_0021;
	}

IL_0021:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = V_0;
		return L_10;
	}
}
// Method Definition Index: 691
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int64_t BitConverter_DoubleToInt64Bits_m4F42741818550F9956B5FBAF88C051F4DE5B0AE6_inline (double ___0_value, const RuntimeMethod* method) 
{
	{
		int64_t L_0 = *((int64_t*)((uintptr_t)(&___0_value)));
		return L_0;
	}
}
// Method Definition Index: 45000
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_op_Subtraction_mB6036E9849D95650D6E73DA0D179CD7B61E696F2_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_lhs, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_rhs, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float3.gen.cs:305>
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_2 = ___1_rhs;
		float L_3 = L_2.___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_4 = ___0_lhs;
		float L_5 = L_4.___y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_6 = ___1_rhs;
		float L_7 = L_6.___y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_8 = ___0_lhs;
		float L_9 = L_8.___z;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_10 = ___1_rhs;
		float L_11 = L_10.___z;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_12;
		memset((&L_12), 0, sizeof(L_12));
		float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline((&L_12), ((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)), ((float)il2cpp_codegen_subtract(L_9, L_11)), NULL);
		return L_12;
	}
}
// Method Definition Index: 41687
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_length_m6A2B63D7A3B84261C2F7FCAA2CB382288A57D257_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_x, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:3618>
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_0 = ___0_x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_1 = ___0_x;
		float L_2;
		L_2 = math_dot_mE193D8880350D74CC8D63A0D53CDC5902F844AAD_inline(L_0, L_1, NULL);
		float L_3;
		L_3 = math_sqrt_mEF31DE7BD0179009683C5D7B0C58E6571B30CF4A_inline(L_2, NULL);
		return L_3;
	}
}
// Method Definition Index: 41316
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:929>
		float L_0 = ___1_y;
		bool L_1;
		L_1 = Single_IsNaN_mFE637F6ECA9F7697CE8EFF56427858F4C5EDF75D_inline(L_0, NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		float L_2 = ___0_x;
		float L_3 = ___1_y;
		if ((((float)L_2) < ((float)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		float L_4 = ___1_y;
		return L_4;
	}

IL_000e:
	{
		float L_5 = ___0_x;
		return L_5;
	}
}
// Method Definition Index: 41334
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:1061>
		float L_0 = ___1_y;
		bool L_1;
		L_1 = Single_IsNaN_mFE637F6ECA9F7697CE8EFF56427858F4C5EDF75D_inline(L_0, NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		float L_2 = ___0_x;
		float L_3 = ___1_y;
		if ((((float)L_2) > ((float)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		float L_4 = ___1_y;
		return L_4;
	}

IL_000e:
	{
		float L_5 = ___0_x;
		return L_5;
	}
}
// Method Definition Index: 37461
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Vector3_Magnitude_m21652D951393A3D7CE92CE40049A0E7F76544D1B_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_vector, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_vector;
		float L_1 = L_0.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___0_vector;
		float L_3 = L_2.___x;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_vector;
		float L_5 = L_4.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___0_vector;
		float L_7 = L_6.___y;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_vector;
		float L_9 = L_8.___z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___0_vector;
		float L_11 = L_10.___z;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		double L_12;
		L_12 = sqrt(((double)((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1, L_3)), ((float)il2cpp_codegen_multiply(L_5, L_7)))), ((float)il2cpp_codegen_multiply(L_9, L_11))))));
		V_0 = ((float)L_12);
		goto IL_0034;
	}

IL_0034:
	{
		float L_13 = V_0;
		return L_13;
	}
}
// Method Definition Index: 37478
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Multiply_m87BA7C578F96C8E49BB07088DAAC4649F83B0353_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x;
		float L_2 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3 = ___0_a;
		float L_4 = L_3.___y;
		float L_5 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___0_a;
		float L_7 = L_6.___z;
		float L_8 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_9;
		memset((&L_9), 0, sizeof(L_9));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_9), ((float)il2cpp_codegen_multiply(L_1, L_2)), ((float)il2cpp_codegen_multiply(L_4, L_5)), ((float)il2cpp_codegen_multiply(L_7, L_8)), NULL);
		V_0 = L_9;
		goto IL_0021;
	}

IL_0021:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = V_0;
		return L_10;
	}
}
// Method Definition Index: 37494
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Quaternion__ctor_m868FD60AA65DD5A8AC0C5DEB0608381A8D85FCD8_inline (Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974* __this, float ___0_x, float ___1_y, float ___2_z, float ___3_w, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x = L_0;
		float L_1 = ___1_y;
		__this->___y = L_1;
		float L_2 = ___2_z;
		__this->___z = L_2;
		float L_3 = ___3_w;
		__this->___w = L_3;
		return;
	}
}
// Method Definition Index: 41306
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_min_m02D43DF516544C279AF660EA4731449C82991849_inline (int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:855>
		int32_t L_0 = ___0_x;
		int32_t L_1 = ___1_y;
		if ((((int32_t)L_0) < ((int32_t)L_1)))
		{
			goto IL_0006;
		}
	}
	{
		int32_t L_2 = ___1_y;
		return L_2;
	}

IL_0006:
	{
		int32_t L_3 = ___0_x;
		return L_3;
	}
}
// Method Definition Index: 41324
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline (int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:987>
		int32_t L_0 = ___0_x;
		int32_t L_1 = ___1_y;
		if ((((int32_t)L_0) > ((int32_t)L_1)))
		{
			goto IL_0006;
		}
	}
	{
		int32_t L_2 = ___1_y;
		return L_2;
	}

IL_0006:
	{
		int32_t L_3 = ___0_x;
		return L_3;
	}
}
// Method Definition Index: 44673
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float2.gen.cs:38>
		float L_0 = ___0_x;
		__this->___x = L_0;
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float2.gen.cs:39>
		float L_1 = ___1_y;
		__this->___y = L_1;
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float2.gen.cs:40>
		return;
	}
}
// Method Definition Index: 44968
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float3.gen.cs:41>
		float L_0 = ___0_x;
		__this->___x = L_0;
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float3.gen.cs:42>
		float L_1 = ___1_y;
		__this->___y = L_1;
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float3.gen.cs:43>
		float L_2 = ___2_z;
		__this->___z = L_2;
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/float3.gen.cs:44>
		return;
	}
}
// Method Definition Index: 41439
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_dot_mE193D8880350D74CC8D63A0D53CDC5902F844AAD_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_x, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_y, const RuntimeMethod* method) 
{
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:1967>
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_0 = ___0_x;
		float L_1 = L_0.___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_2 = ___1_y;
		float L_3 = L_2.___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_4 = ___0_x;
		float L_5 = L_4.___y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_6 = ___1_y;
		float L_7 = L_6.___y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_8 = ___0_x;
		float L_9 = L_8.___z;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_10 = ___1_y;
		float L_11 = L_10.___z;
		return ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1, L_3)), ((float)il2cpp_codegen_multiply(L_5, L_7)))), ((float)il2cpp_codegen_multiply(L_9, L_11))));
	}
}
// Method Definition Index: 41657
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_sqrt_mEF31DE7BD0179009683C5D7B0C58E6571B30CF4A_inline (float ___0_x, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		//<source_info:./Library/PackageCache/com.unity.mathematics@8017b507cc74/Unity.Mathematics/math.cs:3382>
		float L_0 = ___0_x;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		double L_1;
		L_1 = sqrt(((double)((float)L_0)));
		return ((float)L_1);
	}
}
// Method Definition Index: 1919
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Single_IsNaN_mFE637F6ECA9F7697CE8EFF56427858F4C5EDF75D_inline (float ___0_f, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_f;
		int32_t L_1;
		L_1 = BitConverter_SingleToInt32Bits_mC760C7CFC89725E3CF68DC45BE3A9A42A7E7DA73_inline(L_0, NULL);
		return (bool)((((int32_t)((int32_t)(L_1&((int32_t)2147483647LL)))) > ((int32_t)((int32_t)2139095040)))? 1 : 0);
	}
}
// Method Definition Index: 692
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t BitConverter_SingleToInt32Bits_mC760C7CFC89725E3CF68DC45BE3A9A42A7E7DA73_inline (float ___0_value, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = *((int32_t*)((uintptr_t)(&___0_value)));
		return L_0;
	}
}
