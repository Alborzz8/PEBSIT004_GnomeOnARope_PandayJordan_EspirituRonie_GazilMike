﻿#include "pch-c.h"


#include "codegen/il2cpp-codegen-metadata.h"





extern void ConsentState__ctor_mB3407A219590592A7EF832910F3CCD58F9FE72C1 (void);
extern void ConsentState_ToString_mEDD4D983C94831BA4C151A6D05B1906810146665 (void);
extern void EndUserConsent_GetConsentState_mD5E805A905B376D596AAF31A4AB4344535F7CD8E (void);
extern void EndUserConsent_OnConsentStateChanged_m7A2FD500C237FDAE46112404721227038A7A259A (void);
extern void EndUserConsent_GetConsentState_Injected_mFF5752BD0372E6E5E859F47B97185C71D2094D53 (void);
static Il2CppMethodPointer s_methodPointers[5] = 
{
	ConsentState__ctor_mB3407A219590592A7EF832910F3CCD58F9FE72C1,
	ConsentState_ToString_mEDD4D983C94831BA4C151A6D05B1906810146665,
	EndUserConsent_GetConsentState_mD5E805A905B376D596AAF31A4AB4344535F7CD8E,
	EndUserConsent_OnConsentStateChanged_m7A2FD500C237FDAE46112404721227038A7A259A,
	EndUserConsent_GetConsentState_Injected_mFF5752BD0372E6E5E859F47B97185C71D2094D53,
};
extern void ConsentState__ctor_mB3407A219590592A7EF832910F3CCD58F9FE72C1_AdjustorThunk (void);
extern void ConsentState_ToString_mEDD4D983C94831BA4C151A6D05B1906810146665_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[2] = 
{
	{ 0x06000001, ConsentState__ctor_mB3407A219590592A7EF832910F3CCD58F9FE72C1_AdjustorThunk },
	{ 0x06000002, ConsentState_ToString_mEDD4D983C94831BA4C151A6D05B1906810146665_AdjustorThunk },
};
static const int32_t s_InvokerIndices[5] = 
{
	14414,
	14198,
	25004,
	25136,
	23884,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_UnityConsentModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_UnityConsentModule_CodeGenModule = 
{
	"UnityEngine.UnityConsentModule.dll",
	5,
	s_methodPointers,
	2,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
