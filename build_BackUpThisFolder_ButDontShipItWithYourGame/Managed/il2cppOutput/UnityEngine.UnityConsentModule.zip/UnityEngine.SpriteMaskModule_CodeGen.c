﻿#include "pch-c.h"


#include "codegen/il2cpp-codegen-metadata.h"





extern void SpriteMaskUtility_HasSpriteMaskInLayerRange_m7E522D077F4992310FECE3D2911B0C1EE1F72F6B (void);
extern void SpriteMaskUtility_HasSpriteMaskInLayerRange_Injected_m2C4AA54A7B3110F8F11DEEA22FBA36A1CC77B7CD (void);
static Il2CppMethodPointer s_methodPointers[2] = 
{
	SpriteMaskUtility_HasSpriteMaskInLayerRange_m7E522D077F4992310FECE3D2911B0C1EE1F72F6B,
	SpriteMaskUtility_HasSpriteMaskInLayerRange_Injected_m2C4AA54A7B3110F8F11DEEA22FBA36A1CC77B7CD,
};
static const int32_t s_InvokerIndices[2] = 
{
	23220,
	23200,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_SpriteMaskModule_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_SpriteMaskModule_CodeGenModule = 
{
	"UnityEngine.SpriteMaskModule.dll",
	2,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
